var annotated_dup =
[
    [ "post_process_nltk", "namespacepost__process__nltk.html", "namespacepost__process__nltk" ],
    [ "uva", "namespaceuva.html", "namespaceuva" ]
];
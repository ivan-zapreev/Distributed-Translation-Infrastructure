var classuva_1_1utils_1_1containers_1_1dynamic__stack__array =
[
    [ "ELEMENT_TYPE_PTR", "classuva_1_1utils_1_1containers_1_1dynamic__stack__array.html#ab1324861137e6dafb483cb53967f439b", null ],
    [ "TElemType", "classuva_1_1utils_1_1containers_1_1dynamic__stack__array.html#a28bc953e0b84129b26badd8de1c7708f", null ],
    [ "TIndexType", "classuva_1_1utils_1_1containers_1_1dynamic__stack__array.html#af11e2fba505f2b4c1ddf9babf9a1063c", null ],
    [ "dynamic_stack_array", "classuva_1_1utils_1_1containers_1_1dynamic__stack__array.html#a1754532fe13afc671fb39b7c21180d5d", null ],
    [ "~dynamic_stack_array", "classuva_1_1utils_1_1containers_1_1dynamic__stack__array.html#a22984ca8d2a650bfe9d12614724a0902", null ],
    [ "allocate", "classuva_1_1utils_1_1containers_1_1dynamic__stack__array.html#abeeed1d0abb83f9156eb88df90f409dc", null ],
    [ "data", "classuva_1_1utils_1_1containers_1_1dynamic__stack__array.html#ae1b82ff422b2f9c6e350e74ca5af3bae", null ],
    [ "has_data", "classuva_1_1utils_1_1containers_1_1dynamic__stack__array.html#a2cc81846d67f0ef80fc4f015f3c8c5e0", null ],
    [ "operator[]", "classuva_1_1utils_1_1containers_1_1dynamic__stack__array.html#a7f9603910fd1716ade9d8ec4829deeb8", null ],
    [ "pre_allocate", "classuva_1_1utils_1_1containers_1_1dynamic__stack__array.html#a87a918e1b53a24703705413d15c09a1e", null ],
    [ "shrink", "classuva_1_1utils_1_1containers_1_1dynamic__stack__array.html#a5e87976588d212270bfefe71f876d394", null ],
    [ "size", "classuva_1_1utils_1_1containers_1_1dynamic__stack__array.html#a29162acd67bace7ace958e889602a404", null ],
    [ "sort", "classuva_1_1utils_1_1containers_1_1dynamic__stack__array.html#ab15aa9af1a762c6739a3a43dc54882c5", null ],
    [ "sort", "classuva_1_1utils_1_1containers_1_1dynamic__stack__array.html#a879883a293bd797d2067860ba9fc59c1", null ]
];
var classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1phrase__base =
[
    [ "m_gram_id_type", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1phrase__base.html#a719fe3b2c7cc694329fa19e510dc0ced", null ],
    [ "phrase_base", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1phrase__base.html#a5f5cf6f3a02d35210670fddc3794a5e9", null ],
    [ "phrase_base", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1phrase__base.html#a4a90d74c0471c6138f5998672f813cd1", null ],
    [ "create_phrase_id", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1phrase__base.html#ab5fe0d479fa9abbea371bfdf5f728802", null ],
    [ "get_first_word_idx", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1phrase__base.html#acd969e4edb56c1012456e6ba36a6006a", null ],
    [ "get_last_word_id", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1phrase__base.html#ab903406a8945937eed3fd03b51f425ab", null ],
    [ "get_last_word_idx", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1phrase__base.html#a639c31d8a3591f13e5364721894e0dae", null ],
    [ "get_num_words", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1phrase__base.html#a7faa3090e146e171c62c0cd3949aae46", null ],
    [ "get_phrase_id_ref", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1phrase__base.html#af90235927d603b9b986c88e6c4b8b90a", null ],
    [ "operator[]", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1phrase__base.html#ab5d137326514b5bf3b54cbd5ecbbdd24", null ],
    [ "set_word_ids", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1phrase__base.html#a5e459020950db963fbf36c0700693995", null ],
    [ "word_ids", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1phrase__base.html#a5dc6f9171cf46eb946e30595a24f7d0e", null ]
];
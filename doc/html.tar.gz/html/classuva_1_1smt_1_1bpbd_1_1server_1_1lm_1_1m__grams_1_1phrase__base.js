var classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1phrase__base =
[
    [ "m_gram_id_type", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1phrase__base.html#a719fe3b2c7cc694329fa19e510dc0ced", null ],
    [ "phrase_base", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1phrase__base.html#a5f5cf6f3a02d35210670fddc3794a5e9", null ],
    [ "phrase_base", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1phrase__base.html#a4a90d74c0471c6138f5998672f813cd1", null ],
    [ "create_phrase_id", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1phrase__base.html#a29c398ce4da7863e409a630aaa5d355c", null ],
    [ "get_first_word_idx", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1phrase__base.html#a53491eec73f5eab77783069913752294", null ],
    [ "get_last_word_id", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1phrase__base.html#ac3891f1a77ba5bb1b35d11c17509257c", null ],
    [ "get_last_word_idx", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1phrase__base.html#a133b7df4e048edb8e9209b5212ab3c42", null ],
    [ "get_num_words", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1phrase__base.html#af40a0706c739f1b0496795e64c335536", null ],
    [ "get_phrase_id_ref", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1phrase__base.html#af90235927d603b9b986c88e6c4b8b90a", null ],
    [ "operator[]", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1phrase__base.html#a2ffa85640d41b4fba117a7ae983b82be", null ],
    [ "set_word_ids", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1phrase__base.html#a5e459020950db963fbf36c0700693995", null ],
    [ "word_ids", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1phrase__base.html#a4da41a46aa1ba441cb4e901081b48768", null ]
];
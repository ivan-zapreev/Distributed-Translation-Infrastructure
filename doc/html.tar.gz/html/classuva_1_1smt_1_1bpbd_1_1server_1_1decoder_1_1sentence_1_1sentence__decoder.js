var classuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1sentence_1_1sentence__decoder =
[
    [ "sentence_decoder", "classuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1sentence_1_1sentence__decoder.html#a2826666507da3d8d2c4e2dedf4176578", null ],
    [ "~sentence_decoder", "classuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1sentence_1_1sentence__decoder.html#a92648ac64b630f1ca59dae720aaeb3a5", null ],
    [ "compute_futue_costs", "classuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1sentence_1_1sentence__decoder.html#aa3fc739ecdfe8401906a7bc4a09dfcd5", null ],
    [ "get_trans_info", "classuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1sentence_1_1sentence__decoder.html#af26ae2b34ac9956326bc544f123b53a5", null ],
    [ "initialize_future_costs", "classuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1sentence_1_1sentence__decoder.html#a9e5741c0a91513f75f2b17f5ccb38dcc", null ],
    [ "perform_translation", "classuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1sentence_1_1sentence__decoder.html#a66ed829d6e14d014e57e821e492695e0", null ],
    [ "perform_translation", "classuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1sentence_1_1sentence__decoder.html#a7a93ad48423dad3338e70b2a7f0c5649", null ],
    [ "query_reordering_model", "classuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1sentence_1_1sentence__decoder.html#afb271393a680ca09b3ff5e3fb588fc09", null ],
    [ "query_translation_model", "classuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1sentence_1_1sentence__decoder.html#a87e22dcc71de07d6c9fde0485b86a1ee", null ],
    [ "translate", "classuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1sentence_1_1sentence__decoder.html#af559ed59a3dc8465e2ad29df1cef5b42", null ]
];
var classuva_1_1smt_1_1bpbd_1_1processor_1_1processor__manager =
[
    [ "session_data_struct", "structuva_1_1smt_1_1bpbd_1_1processor_1_1processor__manager_1_1session__data__struct.html", "structuva_1_1smt_1_1bpbd_1_1processor_1_1processor__manager_1_1session__data__struct" ],
    [ "session_data", "classuva_1_1smt_1_1bpbd_1_1processor_1_1processor__manager.html#ac8be1416b4cf8b37a6c77eb6ffd3efef", null ],
    [ "sessions_map", "classuva_1_1smt_1_1bpbd_1_1processor_1_1processor__manager.html#a97514ab763bc6f1d8590da9fa2606920", null ],
    [ "processor_manager", "classuva_1_1smt_1_1bpbd_1_1processor_1_1processor__manager.html#a73022d00edbdc3de84a8b5f1ce498cc3", null ],
    [ "cancel_incomp_jobs", "classuva_1_1smt_1_1bpbd_1_1processor_1_1processor__manager.html#afac0f0a4b602b4ac728ffc277f98466c", null ],
    [ "notify_job_done", "classuva_1_1smt_1_1bpbd_1_1processor_1_1processor__manager.html#a8a9a697d864510e6009fec90fcb05a75", null ],
    [ "post_process", "classuva_1_1smt_1_1bpbd_1_1processor_1_1processor__manager.html#ab67233c83cccf0b95f9768f53b805b6b", null ],
    [ "pre_process", "classuva_1_1smt_1_1bpbd_1_1processor_1_1processor__manager.html#a3f8e3f517b1dc3c5f67d58a848dedb9f", null ],
    [ "process", "classuva_1_1smt_1_1bpbd_1_1processor_1_1processor__manager.html#a6d8b3f1c53549d7c4c8a36e1f7571237", null ],
    [ "report_run_time_info", "classuva_1_1smt_1_1bpbd_1_1processor_1_1processor__manager.html#a7fabe3b59f0ed2cf4dfc554aebc7134d", null ],
    [ "schedule_new_job", "classuva_1_1smt_1_1bpbd_1_1processor_1_1processor__manager.html#a0d85665168aebd5bb166881a58305b51", null ],
    [ "session_is_closed", "classuva_1_1smt_1_1bpbd_1_1processor_1_1processor__manager.html#a206e15a9220566da293ff457449e0d39", null ],
    [ "set_num_threads", "classuva_1_1smt_1_1bpbd_1_1processor_1_1processor__manager.html#ae0344c2d8223d7d7bd44e14343283c43", null ],
    [ "stop", "classuva_1_1smt_1_1bpbd_1_1processor_1_1processor__manager.html#a6a1dadeaee3033787fdab9af0c3df558", null ]
];
var classasio_1_1ssl_1_1detail_1_1buffered__handshake__op =
[
    [ "buffered_handshake_op", "classasio_1_1ssl_1_1detail_1_1buffered__handshake__op.html#ae835b9479c097d829bebad90a6ae130f", null ],
    [ "call_handler", "classasio_1_1ssl_1_1detail_1_1buffered__handshake__op.html#ae92797920b5264265725521e08cc746b", null ],
    [ "operator()", "classasio_1_1ssl_1_1detail_1_1buffered__handshake__op.html#af2df0903bf007cd13b16f1cc6238edd6", null ]
];
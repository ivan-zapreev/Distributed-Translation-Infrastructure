var _train_functions_8py =
[
    [ "checkSentenceSanity", "_train_functions_8py.html#a1c1b62cb4b42daa2d8da6d7b225633ae", null ],
    [ "getCasing", "_train_functions_8py.html#a7019b423f90adf634f0482f90eb212b0", null ],
    [ "updateDistributionsFromNgrams", "_train_functions_8py.html#aaad47dc53774dba260cc713f1e3d3c68", null ],
    [ "updateDistributionsFromSentences", "_train_functions_8py.html#a03bc04eccf182ef11921b491ffa99cad", null ]
];
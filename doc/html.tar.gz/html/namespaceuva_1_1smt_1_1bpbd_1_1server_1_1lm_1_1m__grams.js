var namespaceuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams =
[
    [ "m_gram_id", "namespaceuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1m__gram__id.html", "namespaceuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1m__gram__id" ],
    [ "m_gram_payload_s", "structuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1m__gram__payload__s.html", "structuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1m__gram__payload__s" ],
    [ "model_m_gram", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1model__m__gram.html", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1model__m__gram" ],
    [ "phrase_base", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1phrase__base.html", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1phrase__base" ],
    [ "query_m_gram", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1query__m__gram.html", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1query__m__gram" ]
];
var classuva_1_1smt_1_1bpbd_1_1client_1_1messaging_1_1proc__req__out =
[
    [ "set_chunk", "classuva_1_1smt_1_1bpbd_1_1client_1_1messaging_1_1proc__req__out.html#a11a61a41002f64c4cc8ddd4c3ee53740", null ],
    [ "set_job_uid", "classuva_1_1smt_1_1bpbd_1_1client_1_1messaging_1_1proc__req__out.html#a930261cb4be67ca987d4528537a729f4", null ],
    [ "set_language", "classuva_1_1smt_1_1bpbd_1_1client_1_1messaging_1_1proc__req__out.html#a8ad3109a1e700d159ab082aa1a434443", null ]
];
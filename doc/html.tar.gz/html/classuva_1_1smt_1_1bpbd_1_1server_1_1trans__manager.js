var classuva_1_1smt_1_1bpbd_1_1server_1_1trans__manager =
[
    [ "handlers_map_iter_type", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__manager.html#adec62cec51f0ade28dbf9311b3a3b4ad", null ],
    [ "handlers_map_type", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__manager.html#ad5d869b7da9455a2903c5682dde5bcfe", null ],
    [ "response_sender", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__manager.html#ac7a3a0d2d4e7d21b2ce55161bf84f53e", null ],
    [ "sessions_map_type", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__manager.html#aea69500c7a8a6bcb5b2035a684537bcb", null ],
    [ "trans_manager", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__manager.html#a053a8f5be8b004358e5e20b3a1810efb", null ],
    [ "~trans_manager", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__manager.html#aa63b92c7bc0fdc41b879d02f16563506", null ],
    [ "close_session", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__manager.html#a52ec4ea1281d987909f26d9775d7a543", null ],
    [ "notify_job_finished", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__manager.html#a027b8ceba8cf5ac3f21c5963033d4653", null ],
    [ "open_session", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__manager.html#ac1d444c0788fe1ebbd2e771bff2dd5b9", null ],
    [ "report_run_time_info", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__manager.html#ab943355ee7859a85c9d0e0cc6fd57206", null ],
    [ "set_num_threads", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__manager.html#a27073dba1257cacb734cc1063f2ee647", null ],
    [ "set_response_sender", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__manager.html#a03bbff4118af58730ae43c9088203e00", null ],
    [ "stop", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__manager.html#a8c538e77c532642d4ecd2cd2655f5db7", null ],
    [ "translate", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__manager.html#adfc5b34f1b6e6211f3c87626ccc2cfa0", null ]
];
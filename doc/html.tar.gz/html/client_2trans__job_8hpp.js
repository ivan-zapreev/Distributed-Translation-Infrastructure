var client_2trans__job_8hpp =
[
    [ "trans_job", "structuva_1_1smt_1_1bpbd_1_1client_1_1trans__job.html", "structuva_1_1smt_1_1bpbd_1_1client_1_1trans__job" ],
    [ "trans_job_ptr", "client_2trans__job_8hpp.html#a9de0122a1e3e5b28765f0b7b06449aa5", null ]
];
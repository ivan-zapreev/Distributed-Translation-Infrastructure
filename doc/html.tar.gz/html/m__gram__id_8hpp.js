var m__gram__id_8hpp =
[
    [ "T_Gram_Id_Key", "structuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1m__gram__id_1_1_t___gram___id___key.html", "structuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1m__gram__id_1_1_t___gram___id___key" ],
    [ "Byte_M_Gram_Id", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1m__gram__id_1_1_byte___m___gram___id.html", null ],
    [ "DECLARE_STACK_GRAM_ID", "m__gram__id_8hpp.html#af7a55b666ec66abb08a14f939dcb3db4", null ],
    [ "MAX_N_GRAM_ID_LEN_BYTES", "m__gram__id_8hpp.html#a5a110b6715dcc27ba7f3429fedc1496f", null ],
    [ "N_GRAM_ID_TYPE_LEN_BYTES", "m__gram__id_8hpp.html#ac6b2aaaa1c4c542db69a1f59c2245a86", null ],
    [ "TM_Gram_Id_Value_Ptr", "m__gram__id_8hpp.html#aa605051ded9336178d905e9581702378", null ]
];
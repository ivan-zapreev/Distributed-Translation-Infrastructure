var classuva_1_1smt_1_1bpbd_1_1server_1_1trans__task__pool =
[
    [ "tasks_queue_iter_type", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__task__pool.html#a9188b77cca863f71b4a8eb42ee7ffd20", null ],
    [ "tasks_queue_type", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__task__pool.html#a854d6c3235224e2b976ab92b450461eb", null ],
    [ "threads_list_type", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__task__pool.html#a0e3629aa32806e575a5690f7cbc78980", null ],
    [ "workers_list_type", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__task__pool.html#added329421092deb379f0a52935ab18b", null ],
    [ "trans_task_pool", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__task__pool.html#a8495bbbd05167cfe47d0c2638e9d84ac", null ],
    [ "~trans_task_pool", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__task__pool.html#a9ad96e6069c01179f14bd0333029234d", null ],
    [ "notify_task_cancel", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__task__pool.html#a79d4c7977c98b55679b00ae18b6158f1", null ],
    [ "plan_new_task", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__task__pool.html#a03e800374f485e13ef8c4c7e39d8db39", null ],
    [ "report_run_time_info", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__task__pool.html#a1c200441061258c47116296c2181837b", null ],
    [ "set_num_threads", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__task__pool.html#a8da55553e04554165e4c8d983255ef63", null ],
    [ "trans_task_pool_worker", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__task__pool.html#a7736eb5d0c376b16fcd53d37de985e1c", null ],
    [ "m_condition", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__task__pool.html#a825b14e27717f701f7d7f100e2e570dc", null ],
    [ "m_queue_mutex", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__task__pool.html#af8a9fdb7cfbd07cec5c572a7efe58810", null ],
    [ "m_stop", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__task__pool.html#a60febff93f48cda3adba96429692660e", null ],
    [ "m_tasks", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__task__pool.html#a5d7745f1dc249cfb29fa382fbb66d25f", null ]
];
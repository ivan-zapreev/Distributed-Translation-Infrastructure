var dir_19d568841146c10f9f3f51cd33f5fbe1 =
[
    [ "supp_lang_req_out.hpp", "supp__lang__req__out_8hpp.html", [
      [ "supp_lang_req_out", "classuva_1_1smt_1_1bpbd_1_1client_1_1messaging_1_1supp__lang__req__out.html", "classuva_1_1smt_1_1bpbd_1_1client_1_1messaging_1_1supp__lang__req__out" ]
    ] ],
    [ "supp_lang_resp_in.hpp", "supp__lang__resp__in_8hpp.html", [
      [ "supp_lang_resp_in", "classuva_1_1smt_1_1bpbd_1_1client_1_1messaging_1_1supp__lang__resp__in.html", "classuva_1_1smt_1_1bpbd_1_1client_1_1messaging_1_1supp__lang__resp__in" ]
    ] ],
    [ "trans_job_req_out.hpp", "trans__job__req__out_8hpp.html", [
      [ "trans_job_req_out", "classuva_1_1smt_1_1bpbd_1_1client_1_1messaging_1_1trans__job__req__out.html", "classuva_1_1smt_1_1bpbd_1_1client_1_1messaging_1_1trans__job__req__out" ]
    ] ],
    [ "trans_job_resp_in.hpp", "trans__job__resp__in_8hpp.html", [
      [ "trans_job_resp_in", "classuva_1_1smt_1_1bpbd_1_1client_1_1messaging_1_1trans__job__resp__in.html", "classuva_1_1smt_1_1bpbd_1_1client_1_1messaging_1_1trans__job__resp__in" ]
    ] ],
    [ "trans_sent_data_in.hpp", "trans__sent__data__in_8hpp.html", [
      [ "trans_sent_data_in", "classuva_1_1smt_1_1bpbd_1_1client_1_1messaging_1_1trans__sent__data__in.html", "classuva_1_1smt_1_1bpbd_1_1client_1_1messaging_1_1trans__sent__data__in" ]
    ] ]
];
var namespaceuva_1_1utils_1_1math =
[
    [ "bits", "namespaceuva_1_1utils_1_1math_1_1bits.html", null ],
    [ "const_expr", "namespaceuva_1_1utils_1_1math_1_1const__expr.html", null ],
    [ "log2", "namespaceuva_1_1utils_1_1math_1_1log2.html", null ]
];
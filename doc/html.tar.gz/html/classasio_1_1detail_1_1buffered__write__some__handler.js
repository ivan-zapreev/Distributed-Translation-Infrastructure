var classasio_1_1detail_1_1buffered__write__some__handler =
[
    [ "buffered_write_some_handler", "classasio_1_1detail_1_1buffered__write__some__handler.html#af2784930fb8df930dfad9cc378b54c23", null ],
    [ "operator()", "classasio_1_1detail_1_1buffered__write__some__handler.html#a006c777b1316275f13d32a3a37be6447", null ],
    [ "buffers_", "classasio_1_1detail_1_1buffered__write__some__handler.html#a3c09e3a75a53b491cbdcaa3c3fe3f4b5", null ],
    [ "handler_", "classasio_1_1detail_1_1buffered__write__some__handler.html#a8a01d41c2ea0751dd1ef511c4ceb17e6", null ],
    [ "storage_", "classasio_1_1detail_1_1buffered__write__some__handler.html#a26506a056c3ed5dc287fa2183b4e2174", null ]
];
var classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1trans__job__code =
[
    [ "values", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1trans__job__code.html#af641dab8b5a194daece857d972f5351f", [
      [ "RESULT_UNDEFINED", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1trans__job__code.html#af641dab8b5a194daece857d972f5351fa3733780325b11ee9dfe03569b56f7cfa", null ],
      [ "RESULT_OK", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1trans__job__code.html#af641dab8b5a194daece857d972f5351fa42d738642764ef67bdee43ad6d92efea", null ],
      [ "RESULT_ERROR", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1trans__job__code.html#af641dab8b5a194daece857d972f5351faaa721a0ec3217a4248932b03065fd290", null ],
      [ "RESULT_CANCELED", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1trans__job__code.html#af641dab8b5a194daece857d972f5351fa0b5251fd3a50d63861d6ffdc2c1005e3", null ],
      [ "RESULT_PARTIAL", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1trans__job__code.html#af641dab8b5a194daece857d972f5351fad8175f268ab05068fd325a700c0474fe", null ],
      [ "size", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1trans__job__code.html#af641dab8b5a194daece857d972f5351fa1d0b95aa6b3affd97a603a811e5b3759", null ]
    ] ],
    [ "trans_job_code", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1trans__job__code.html#a2b12e7d193eb2061c62b9f0667910388", null ],
    [ "trans_job_code", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1trans__job__code.html#a1c0fc0665b7a83251fa8e3760cffc50e", null ],
    [ "trans_job_code", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1trans__job__code.html#aee06d7ab9cabaa8342b1cd320d8300d7", null ],
    [ "operator int", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1trans__job__code.html#ab743b5a1ba658804ccc5eb85b102ce41", null ],
    [ "operator string", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1trans__job__code.html#ab7a14ca22f6ee97433648ef964657a49", null ],
    [ "operator<", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1trans__job__code.html#a1f8eea31d4be1f1281733fa704cc0b05", null ],
    [ "operator=", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1trans__job__code.html#a2a61255369a29c97c498cd736950882d", null ],
    [ "operator==", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1trans__job__code.html#affdcadf5976bba63184652526b0aea10", null ],
    [ "str", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1trans__job__code.html#a171d63c49c19eb6eb2be886583ddc92f", null ],
    [ "val", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1trans__job__code.html#a5bc78edfe91877b22a2ed1de0614fc72", null ]
];
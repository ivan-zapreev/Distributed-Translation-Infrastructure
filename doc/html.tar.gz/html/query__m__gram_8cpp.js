var query__m__gram_8cpp =
[
    [ "operator<<", "query__m__gram_8cpp.html#a111d69ca51f322c5ab49f88844a895af", null ]
];
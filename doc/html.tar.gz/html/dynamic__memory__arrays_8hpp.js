var dynamic__memory__arrays_8hpp =
[
    [ "mem_increase_strategy", "classuva_1_1utils_1_1containers_1_1mem__increase__strategy.html", "classuva_1_1utils_1_1containers_1_1mem__increase__strategy" ],
    [ "ELEMENT_DEALLOC_FUNC", "structuva_1_1utils_1_1containers_1_1_e_l_e_m_e_n_t___d_e_a_l_l_o_c___f_u_n_c.html", "structuva_1_1utils_1_1containers_1_1_e_l_e_m_e_n_t___d_e_a_l_l_o_c___f_u_n_c" ],
    [ "dynamic_stack_array", "classuva_1_1utils_1_1containers_1_1dynamic__stack__array.html", "classuva_1_1utils_1_1containers_1_1dynamic__stack__array" ],
    [ "EXTRACT_C", "dynamic__memory__arrays_8hpp.html#a20e08c3597f7e9e569ae3883bdbccb53", null ],
    [ "EXTRACT_P", "dynamic__memory__arrays_8hpp.html#a2e1fb9a2678412cfb3d26581fa8987ee", null ],
    [ "EXTRACT_PC", "dynamic__memory__arrays_8hpp.html#afe4093fcbdaa9d7d0c88bf644e4f4c70", null ],
    [ "EXTRACT_PCS", "dynamic__memory__arrays_8hpp.html#a200b52590ac3f16caafc914a20241e48", null ],
    [ "EXTRACT_PS", "dynamic__memory__arrays_8hpp.html#ad0b54a74d8c35db1e175750c9384169b", null ],
    [ "EXTRACT_S", "dynamic__memory__arrays_8hpp.html#a2c60634a2f3cc01a8b2ece69c4d41b01", null ],
    [ "TCapacityIncFunct", "dynamic__memory__arrays_8hpp.html#ab6acd1b6093503e17f6d8b942e9fccf1", null ],
    [ "mem_inc_types_enum", "dynamic__memory__arrays_8hpp.html#a2dfd5027e0c656e7b8433760967da62d", [
      [ "UNDEFINED", "dynamic__memory__arrays_8hpp.html#a2dfd5027e0c656e7b8433760967da62da378c848dc111a9fb0be352f3e73caaf5", null ],
      [ "CONSTANT", "dynamic__memory__arrays_8hpp.html#a2dfd5027e0c656e7b8433760967da62da2e97241bf53f5da01ef85f408863370d", null ],
      [ "LINEAR", "dynamic__memory__arrays_8hpp.html#a2dfd5027e0c656e7b8433760967da62daef7537589dc0f411a7215b5904b21073", null ],
      [ "LOG_2", "dynamic__memory__arrays_8hpp.html#a2dfd5027e0c656e7b8433760967da62da8ca02671080014d040d3d1c7db41b447", null ],
      [ "LOG_10", "dynamic__memory__arrays_8hpp.html#a2dfd5027e0c656e7b8433760967da62daa0517306d9991f24d02b23c2df9ac368", null ],
      [ "size", "dynamic__memory__arrays_8hpp.html#a2dfd5027e0c656e7b8433760967da62da0be5bdf7cf8c7c58d0bc5678caa07791", null ]
    ] ],
    [ "get_mem_incr_strat", "dynamic__memory__arrays_8hpp.html#a04ae8ecdaffa42ace76f1c604659ba6c", null ],
    [ "_memIncTypesEnumStr", "dynamic__memory__arrays_8hpp.html#af8fa681c6894f17bfa25c736eb3d8ce8", null ]
];
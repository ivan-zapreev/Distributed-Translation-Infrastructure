var dir_e8de4d087f539174efc5421fdfe2cfe0 =
[
    [ "afile_reader.hpp", "afile__reader_8hpp.html", [
      [ "afile_reader", "classuva_1_1utils_1_1file_1_1afile__reader.html", "classuva_1_1utils_1_1file_1_1afile__reader" ]
    ] ],
    [ "cstyle_file_reader.hpp", "cstyle__file__reader_8hpp.html", [
      [ "cstyle_file_reader", "classuva_1_1utils_1_1file_1_1cstyle__file__reader.html", "classuva_1_1utils_1_1file_1_1cstyle__file__reader" ]
    ] ],
    [ "file_stream_reader.hpp", "file__stream__reader_8hpp.html", [
      [ "file_stream_reader", "classuva_1_1utils_1_1file_1_1file__stream__reader.html", "classuva_1_1utils_1_1file_1_1file__stream__reader" ]
    ] ],
    [ "memory_mapped_file_reader.hpp", "memory__mapped__file__reader_8hpp.html", "memory__mapped__file__reader_8hpp" ],
    [ "text_piece_reader.hpp", "text__piece__reader_8hpp.html", "text__piece__reader_8hpp" ]
];
var dir_7626aeb94e24718bccf226a5b3a9cf92 =
[
    [ "EvaluateTruecaser.py", "_evaluate_truecaser_8py.html", "_evaluate_truecaser_8py" ],
    [ "TrainFunctions.py", "_train_functions_8py.html", "_train_functions_8py" ],
    [ "TrainTruecaser.py", "_train_truecaser_8py.html", "_train_truecaser_8py" ],
    [ "Truecaser.py", "_truecaser_8py.html", "_truecaser_8py" ]
];
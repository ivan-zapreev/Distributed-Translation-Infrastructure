var classasio_1_1ssl_1_1stream__base =
[
    [ "handshake_type", "classasio_1_1ssl_1_1stream__base.html#a2f18813d3860bc8aee99249834d7c320", [
      [ "client", "classasio_1_1ssl_1_1stream__base.html#a2f18813d3860bc8aee99249834d7c320a68134fb041cb11ffe46e248ed1e1d73f", null ],
      [ "server", "classasio_1_1ssl_1_1stream__base.html#a2f18813d3860bc8aee99249834d7c320a2f9bac13b8adb5945e7436945061d090", null ]
    ] ],
    [ "~stream_base", "classasio_1_1ssl_1_1stream__base.html#af44f60fc18949a1235701c7ab76848b8", null ]
];
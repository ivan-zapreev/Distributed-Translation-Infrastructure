var classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1proxy_1_1lm__proxy__local =
[
    [ "lm_proxy_local", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1proxy_1_1lm__proxy__local.html#a1aa62dbdb57c77b3014169b4b9c5c215", null ],
    [ "~lm_proxy_local", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1proxy_1_1lm__proxy__local.html#ab279218f8d6268eb7702df5d3c4137ac", null ],
    [ "allocate_fast_query_proxy", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1proxy_1_1lm__proxy__local.html#ab2c1055d26c52e84e2171811662446ab", null ],
    [ "allocate_slow_query_proxy", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1proxy_1_1lm__proxy__local.html#a95bc77c757872fbdbaa65f31a8bb3228", null ],
    [ "connect", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1proxy_1_1lm__proxy__local.html#ac39bb53d1609bb380a9e252a18023806", null ],
    [ "disconnect", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1proxy_1_1lm__proxy__local.html#a1d27c446b7f9e370c874daac3a38535a", null ],
    [ "dispose_fast_query_proxy", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1proxy_1_1lm__proxy__local.html#a1cc247ccdb00831f196d15cd9ab9eeaa", null ],
    [ "dispose_slow_query_proxy", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1proxy_1_1lm__proxy__local.html#a2702b2498c14bc79df89484893ee3fc7", null ],
    [ "m_begin_tag_uid", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1proxy_1_1lm__proxy__local.html#adf9f94e10e1d210e35c7716b08b89977", null ],
    [ "m_end_tag_uid", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1proxy_1_1lm__proxy__local.html#a656493c20699367286febb880cbf1ca1", null ],
    [ "m_model", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1proxy_1_1lm__proxy__local.html#ac9984821921672cd3ee113005d5412dd", null ],
    [ "m_unk_word_prob", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1proxy_1_1lm__proxy__local.html#a429b9054d6edfc673d541cb957b52690", null ],
    [ "m_word_index", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1proxy_1_1lm__proxy__local.html#a52e51098548cbedd08af9b5b6fc897c8", null ]
];
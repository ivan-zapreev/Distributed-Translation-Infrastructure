var dir_09570de3dfb316c313be7ac6593bd1a2 =
[
    [ "models", "dir_788ec55872e212b32572c0ce47461ceb.html", "dir_788ec55872e212b32572c0ce47461ceb" ],
    [ "feature_id_registry.hpp", "feature__id__registry_8hpp.html", [
      [ "feature_id_registry", "classuva_1_1smt_1_1bpbd_1_1server_1_1common_1_1feature__id__registry.html", "classuva_1_1smt_1_1bpbd_1_1server_1_1common_1_1feature__id__registry" ]
    ] ]
];
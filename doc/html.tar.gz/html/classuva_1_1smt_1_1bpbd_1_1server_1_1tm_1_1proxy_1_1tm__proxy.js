var classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1proxy_1_1tm__proxy =
[
    [ "~tm_proxy", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1proxy_1_1tm__proxy.html#a43110714b48c4dff9dc63c882f9fea0d", null ],
    [ "allocate_query_proxy", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1proxy_1_1tm__proxy.html#ad038abb503116db63fe0ade0646a67fa", null ],
    [ "connect", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1proxy_1_1tm__proxy.html#a709c4823b451310b5e6559d37ec349c5", null ],
    [ "disconnect", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1proxy_1_1tm__proxy.html#af7c0b4637c6aaa4bac87f33fd034cff6", null ],
    [ "dispose_query_proxy", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1proxy_1_1tm__proxy.html#a5125504cef8c1843a65255dc6e846ae0", null ]
];
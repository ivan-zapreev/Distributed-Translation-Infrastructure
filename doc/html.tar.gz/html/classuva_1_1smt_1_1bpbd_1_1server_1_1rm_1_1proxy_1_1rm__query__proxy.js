var classuva_1_1smt_1_1bpbd_1_1server_1_1rm_1_1proxy_1_1rm__query__proxy =
[
    [ "~rm_query_proxy", "classuva_1_1smt_1_1bpbd_1_1server_1_1rm_1_1proxy_1_1rm__query__proxy.html#a5eea567e6c06a5aca6c1843fb5a5600f", null ],
    [ "execute", "classuva_1_1smt_1_1bpbd_1_1server_1_1rm_1_1proxy_1_1rm__query__proxy.html#a98146bf871df1c1c25ee767a6789b0fd", null ],
    [ "get_begin_tag_reordering", "classuva_1_1smt_1_1bpbd_1_1server_1_1rm_1_1proxy_1_1rm__query__proxy.html#a9d1d1399e281abd8130c5f9985c6adef", null ],
    [ "get_end_tag_reordering", "classuva_1_1smt_1_1bpbd_1_1server_1_1rm_1_1proxy_1_1rm__query__proxy.html#a5132d9c93a19a69d6797ce27a63a3770", null ],
    [ "get_reordering", "classuva_1_1smt_1_1bpbd_1_1server_1_1rm_1_1proxy_1_1rm__query__proxy.html#a951915706f19d80a7d39c61b7a4ec191", null ]
];
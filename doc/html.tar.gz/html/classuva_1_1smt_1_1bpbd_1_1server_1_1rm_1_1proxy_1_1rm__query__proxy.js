var classuva_1_1smt_1_1bpbd_1_1server_1_1rm_1_1proxy_1_1rm__query__proxy =
[
    [ "~rm_query_proxy", "classuva_1_1smt_1_1bpbd_1_1server_1_1rm_1_1proxy_1_1rm__query__proxy.html#a5eea567e6c06a5aca6c1843fb5a5600f", null ],
    [ "execute", "classuva_1_1smt_1_1bpbd_1_1server_1_1rm_1_1proxy_1_1rm__query__proxy.html#a98146bf871df1c1c25ee767a6789b0fd", null ],
    [ "get_begin_tag_reordering", "classuva_1_1smt_1_1bpbd_1_1server_1_1rm_1_1proxy_1_1rm__query__proxy.html#ad3c21a9dee195e1cd72bed342fcac15f", null ],
    [ "get_end_tag_reordering", "classuva_1_1smt_1_1bpbd_1_1server_1_1rm_1_1proxy_1_1rm__query__proxy.html#a752b935806e2165df1fb95a6fa68d3d0", null ],
    [ "get_reordering", "classuva_1_1smt_1_1bpbd_1_1server_1_1rm_1_1proxy_1_1rm__query__proxy.html#a16a68e55c35c1cb1a76cb101d01b4558", null ]
];
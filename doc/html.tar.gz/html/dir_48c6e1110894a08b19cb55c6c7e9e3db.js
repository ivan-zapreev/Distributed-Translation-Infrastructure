var dir_48c6e1110894a08b19cb55c6c7e9e3db =
[
    [ "library", "dir_9531f8c5f55e652384656b550ab0b317.html", "dir_9531f8c5f55e652384656b550ab0b317" ],
    [ "client_common.js", "client__common_8js.html", null ],
    [ "file_up_down.js", "file__up__down_8js.html", null ],
    [ "languages.js", "languages_8js.html", null ],
    [ "logger.js", "logger_8js.html", null ],
    [ "post_proc_client.js", "post__proc__client_8js.html", null ],
    [ "pre_proc_client.js", "pre__proc__client_8js.html", null ],
    [ "proc_client.js", "proc__client_8js.html", null ],
    [ "translate.js", "translate_8js.html", null ],
    [ "translation_client.js", "translation__client_8js.html", null ],
    [ "ws_client.js", "ws__client_8js.html", null ]
];
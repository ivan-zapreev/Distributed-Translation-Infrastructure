var structuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1stack_1_1state__data__templ =
[
    [ "covered_info", "structuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1stack_1_1state__data__templ.html#a82c1c3c6ae956a4f3b6c4463208caeb2", null ],
    [ "stack_data", "structuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1stack_1_1state__data__templ.html#acefce9c74e0df4af27ec01393d84e37a", null ],
    [ "state_frame", "structuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1stack_1_1state__data__templ.html#af9bf10c44920264f6e5af72c53b911d1", null ],
    [ "m_begin_lm_level", "structuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1stack_1_1state__data__templ.html#ae7e8ad963527c0433e9542fdebc5d847", null ],
    [ "m_covered", "structuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1stack_1_1state__data__templ.html#a823750138d029b9f8dbf2381b37c0b02", null ],
    [ "m_partial_score", "structuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1stack_1_1state__data__templ.html#a5e5a7a9d8ed70e6165223ddace152bc7", null ],
    [ "m_s_begin_word_idx", "structuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1stack_1_1state__data__templ.html#a93882c26c5679e193617ee62da2586b3", null ],
    [ "m_s_end_word_idx", "structuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1stack_1_1state__data__templ.html#ab330d6661407b2ff8fb9ab590e46b770", null ],
    [ "m_stack_level", "structuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1stack_1_1state__data__templ.html#a503c5b3098874fee88cac9faf6698012", null ],
    [ "m_target", "structuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1stack_1_1state__data__templ.html#a3cc90993269e9b49a869db0fd29fd360", null ],
    [ "m_total_score", "structuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1stack_1_1state__data__templ.html#a3849018404fe0a32ac1bf5d9ca769b08", null ],
    [ "m_trans_frame", "structuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1stack_1_1state__data__templ.html#a5227cdabe8fedce75ea16f66af5f7c72", null ],
    [ "rm_entry_data", "structuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1stack_1_1state__data__templ.html#a82eb70f8637c83ceb80aa5ea93dbff45", null ]
];
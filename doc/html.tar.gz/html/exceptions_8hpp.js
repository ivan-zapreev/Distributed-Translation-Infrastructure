var exceptions_8hpp =
[
    [ "uva_exception", "classuva_1_1utils_1_1exceptions_1_1uva__exception.html", "classuva_1_1utils_1_1exceptions_1_1uva__exception" ],
    [ "ASSERT_CONDITION_THROW", "exceptions_8hpp.html#a7cbdcc40e072e9104a2d56c864528443", null ],
    [ "ASSERT_SANITY_THROW", "exceptions_8hpp.html#a6da7c6aba7d6422f70b6b1597f38e143", null ],
    [ "THROW_EXCEPTION", "exceptions_8hpp.html#af0cef80fd59702870671c5b0aff6308d", null ],
    [ "THROW_MUST_NOT_CALL", "exceptions_8hpp.html#aa48cae2efe78985f442077587947c5ef", null ],
    [ "THROW_MUST_OVERRIDE", "exceptions_8hpp.html#a26bbf40c42ee9bdf40814bf74e3470a2", null ],
    [ "THROW_NOT_IMPLEMENTED", "exceptions_8hpp.html#a5827f0f7fcb295f12fd11fd17734e3c0", null ],
    [ "DO_SANITY_CHECKS", "exceptions_8hpp.html#ae769de24af658b2759564fbbfea5c5f0", null ]
];
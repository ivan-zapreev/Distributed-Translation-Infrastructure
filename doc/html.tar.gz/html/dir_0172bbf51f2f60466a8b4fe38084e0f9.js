var dir_0172bbf51f2f60466a8b4fe38084e0f9 =
[
    [ "messaging.cpp", "client_2messaging_2messaging_8cpp.html", null ]
];
var classuva_1_1smt_1_1bpbd_1_1client_1_1trans__job__status =
[
    [ "values", "classuva_1_1smt_1_1bpbd_1_1client_1_1trans__job__status.html#a80cd5ec4a7e4de9541f48e6b5ccb866d", [
      [ "STATUS_UNDEFINED", "classuva_1_1smt_1_1bpbd_1_1client_1_1trans__job__status.html#a80cd5ec4a7e4de9541f48e6b5ccb866da403360b08f2de0f31675a6583a1f4ac7", null ],
      [ "STATUS_REQ_INITIALIZED", "classuva_1_1smt_1_1bpbd_1_1client_1_1trans__job__status.html#a80cd5ec4a7e4de9541f48e6b5ccb866dac7a7a8c0315692a0510a941f87ff511e", null ],
      [ "STATUS_REQ_SENT_GOOD", "classuva_1_1smt_1_1bpbd_1_1client_1_1trans__job__status.html#a80cd5ec4a7e4de9541f48e6b5ccb866da5f6d7d1ddb96bb521fb70ccd59412fa1", null ],
      [ "STATUS_REQ_SENT_FAIL", "classuva_1_1smt_1_1bpbd_1_1client_1_1trans__job__status.html#a80cd5ec4a7e4de9541f48e6b5ccb866da2d39e11101288c3f7ad3532839118b6a", null ],
      [ "STATUS_RES_RECEIVED", "classuva_1_1smt_1_1bpbd_1_1client_1_1trans__job__status.html#a80cd5ec4a7e4de9541f48e6b5ccb866daa494a5f1d4de362fa250266a1baeafd6", null ],
      [ "size", "classuva_1_1smt_1_1bpbd_1_1client_1_1trans__job__status.html#a80cd5ec4a7e4de9541f48e6b5ccb866dad572a16ae4a34b4eae6bc363065c64a9", null ]
    ] ],
    [ "trans_job_status", "classuva_1_1smt_1_1bpbd_1_1client_1_1trans__job__status.html#af9a56ef51172231793447855d3b034b8", null ],
    [ "trans_job_status", "classuva_1_1smt_1_1bpbd_1_1client_1_1trans__job__status.html#aba62ac2555e1061ff10fdb95eeec4504", null ],
    [ "trans_job_status", "classuva_1_1smt_1_1bpbd_1_1client_1_1trans__job__status.html#aab2be3621dba4c96198c91c0f9a2592f", null ],
    [ "operator int", "classuva_1_1smt_1_1bpbd_1_1client_1_1trans__job__status.html#afad7ef7d08fc24afa7e89f577132aa6c", null ],
    [ "operator string", "classuva_1_1smt_1_1bpbd_1_1client_1_1trans__job__status.html#a684cd9cc3e3bca400c1842afb59b433d", null ],
    [ "operator<", "classuva_1_1smt_1_1bpbd_1_1client_1_1trans__job__status.html#a15b8f505c231bc81cc94b6598a12a87b", null ],
    [ "operator=", "classuva_1_1smt_1_1bpbd_1_1client_1_1trans__job__status.html#a421e243d3b4b614d90589279d3b4fdc6", null ],
    [ "operator==", "classuva_1_1smt_1_1bpbd_1_1client_1_1trans__job__status.html#a9cc419b2b5958ad4468e1483a3bd93a6", null ],
    [ "str", "classuva_1_1smt_1_1bpbd_1_1client_1_1trans__job__status.html#ad55dd5249213e5f7968dbc10cfb9fdff", null ]
];
var classuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1stack_1_1stack__state__templ =
[
    [ "const_stack_state_ptr", "classuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1stack_1_1stack__state__templ.html#a597c51e13b04630a38f2d2b486d592d4", null ],
    [ "stack_data", "classuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1stack_1_1stack__state__templ.html#a895dcc74487ff72606c9adca976106a9", null ],
    [ "stack_state", "classuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1stack_1_1stack__state__templ.html#adc25101e7fe87e7fe8e046f6d1af32ca", null ],
    [ "stack_state_ptr", "classuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1stack_1_1stack__state__templ.html#a01dbb7151c172e258d2713b21dbbd511", null ],
    [ "state_data", "classuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1stack_1_1stack__state__templ.html#a1fc336e2b0440e673a3b487aa81b4ca7", null ],
    [ "stack_state_templ", "classuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1stack_1_1stack__state__templ.html#ae27c0ac527bc5e0d3778da7cbb0b8798", null ],
    [ "cut_the_tail", "classuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1stack_1_1stack__state__templ.html#ac76b97a1947b7a9655067ed428f18b09", null ],
    [ "expand", "classuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1stack_1_1stack__state__templ.html#adb21e399dbeaea70280852ab8d531e41", null ],
    [ "expand_left", "classuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1stack_1_1stack__state__templ.html#aa817a6db68a871cfa2e6471ce0820166", null ],
    [ "expand_length", "classuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1stack_1_1stack__state__templ.html#a52f58062fa687c72c3e7f907fbaf0bea", null ],
    [ "expand_length_if_not_covered", "classuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1stack_1_1stack__state__templ.html#a67173cc0a431d4f077b86b1523572066", null ],
    [ "expand_right", "classuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1stack_1_1stack__state__templ.html#a510e1b456af15cb1fa7437d459b9d51c", null ],
    [ "expand_trans", "classuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1stack_1_1stack__state__templ.html#a0f77f0583a67910024a6490b43fa5f75", null ],
    [ "get_stack_level", "classuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1stack_1_1stack__state__templ.html#a021425c5adc4df549f8ff7336f0a9593", null ],
    [ "get_translation", "classuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1stack_1_1stack__state__templ.html#a7395ae83975c705246bdfc230609f62d", null ],
    [ "is_above_threshold", "classuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1stack_1_1stack__state__templ.html#a639179e1296b03f61ce896731535fe58", null ],
    [ "operator!=", "classuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1stack_1_1stack__state__templ.html#afdee14bd12ccb4df9d57fc0a57009233", null ],
    [ "operator<", "classuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1stack_1_1stack__state__templ.html#ace39685d82c2eae6b0449996ba160d04", null ],
    [ "operator==", "classuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1stack_1_1stack__state__templ.html#a09270192006a96995a3204f8c46d600d", null ],
    [ "recombine_from", "classuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1stack_1_1stack__state__templ.html#a859ab3946d98193b6d25b0887dfae61a", null ],
    [ "stack_level_templ< is_dist, NUM_WORDS_PER_SENTENCE, MAX_HISTORY_LENGTH, MAX_M_GRAM_QUERY_LENGTH >", "classuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1stack_1_1stack__state__templ.html#ac4c29eb098061a4c21931ee2d69faf08", null ]
];
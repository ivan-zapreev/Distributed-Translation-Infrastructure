var classuva_1_1utils_1_1threads_1_1task__pool =
[
    [ "pool_task_ptr", "classuva_1_1utils_1_1threads_1_1task__pool.html#a5106b57b5f0131c1e344b0a48f17a2cd", null ],
    [ "tasks_queue_iter_type", "classuva_1_1utils_1_1threads_1_1task__pool.html#a7226e5cb4d123d3d5e00d5385181bef0", null ],
    [ "tasks_queue_type", "classuva_1_1utils_1_1threads_1_1task__pool.html#a41e3427a0a2f649f162ffa622f2d9738", null ],
    [ "threads_list_type", "classuva_1_1utils_1_1threads_1_1task__pool.html#abfa8aa3d1f6a4dfa1fe8297b45c7b9fa", null ],
    [ "workers_list_type", "classuva_1_1utils_1_1threads_1_1task__pool.html#adc58f4e0c91fdd809218c217be752fa7", null ],
    [ "task_pool", "classuva_1_1utils_1_1threads_1_1task__pool.html#ac3288d3c706300cecb2671da7e470445", null ],
    [ "~task_pool", "classuva_1_1utils_1_1threads_1_1task__pool.html#a378953fa89e615b74e241806bf63173f", null ],
    [ "plan_new_task", "classuva_1_1utils_1_1threads_1_1task__pool.html#a2a993d821e4de08e9f20afd6b1b83c9f", null ],
    [ "remove_task_from_pool", "classuva_1_1utils_1_1threads_1_1task__pool.html#a7084515c3dcf2b6a892021297e129df9", null ],
    [ "report_run_time_info", "classuva_1_1utils_1_1threads_1_1task__pool.html#aa9d8f3e4ad23b4acbfe855f5fc57c0be", null ],
    [ "set_num_threads", "classuva_1_1utils_1_1threads_1_1task__pool.html#ab563d4857a1f1dbecb65aecf72974b31", null ],
    [ "task_pool_worker< pool_task >", "classuva_1_1utils_1_1threads_1_1task__pool.html#a320b8ec67a974f7094db8d09292de6c0", null ],
    [ "m_condition", "classuva_1_1utils_1_1threads_1_1task__pool.html#a1a7dd3440d6c529c62273d8ded3ba1fd", null ],
    [ "m_queue_mutex", "classuva_1_1utils_1_1threads_1_1task__pool.html#a092173017b3dd165f5d55a5c93949891", null ],
    [ "m_stop", "classuva_1_1utils_1_1threads_1_1task__pool.html#a2594a3693e258091ad6f71326b99a224", null ],
    [ "m_tasks", "classuva_1_1utils_1_1threads_1_1task__pool.html#a6d0a8daf9d224cb92ad8bf84d02d04b2", null ]
];
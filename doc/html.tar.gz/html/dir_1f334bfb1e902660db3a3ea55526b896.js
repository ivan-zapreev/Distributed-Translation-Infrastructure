var dir_1f334bfb1e902660db3a3ea55526b896 =
[
    [ "rm_proxy.hpp", "rm__proxy_8hpp.html", [
      [ "rm_proxy", "classuva_1_1smt_1_1bpbd_1_1server_1_1rm_1_1proxy_1_1rm__proxy.html", "classuva_1_1smt_1_1bpbd_1_1server_1_1rm_1_1proxy_1_1rm__proxy" ]
    ] ],
    [ "rm_proxy_local.hpp", "rm__proxy__local_8hpp.html", [
      [ "rm_proxy_local", "classuva_1_1smt_1_1bpbd_1_1server_1_1rm_1_1proxy_1_1rm__proxy__local.html", "classuva_1_1smt_1_1bpbd_1_1server_1_1rm_1_1proxy_1_1rm__proxy__local" ]
    ] ],
    [ "rm_query_proxy.hpp", "rm__query__proxy_8hpp.html", [
      [ "rm_query_proxy", "classuva_1_1smt_1_1bpbd_1_1server_1_1rm_1_1proxy_1_1rm__query__proxy.html", "classuva_1_1smt_1_1bpbd_1_1server_1_1rm_1_1proxy_1_1rm__query__proxy" ]
    ] ],
    [ "rm_query_proxy_local.hpp", "rm__query__proxy__local_8hpp.html", [
      [ "rm_query_proxy_local", "classuva_1_1smt_1_1bpbd_1_1server_1_1rm_1_1proxy_1_1rm__query__proxy__local.html", "classuva_1_1smt_1_1bpbd_1_1server_1_1rm_1_1proxy_1_1rm__query__proxy__local" ]
    ] ]
];
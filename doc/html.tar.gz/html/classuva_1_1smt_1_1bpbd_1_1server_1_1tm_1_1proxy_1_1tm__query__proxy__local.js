var classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1proxy_1_1tm__query__proxy__local =
[
    [ "tm_query_proxy_local", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1proxy_1_1tm__query__proxy__local.html#a9daacb7e381485a8926633ff027b6494", null ],
    [ "~tm_query_proxy_local", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1proxy_1_1tm__query__proxy__local.html#afe5b180bf9caabd4fc9e898e16caccc7", null ],
    [ "execute", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1proxy_1_1tm__query__proxy__local.html#a4c4222ec70f98b6c2b439e904d2f40a9", null ],
    [ "get_source_entry", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1proxy_1_1tm__query__proxy__local.html#a61cbce7097085593f2cd9c246a438803", null ],
    [ "get_st_uids", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1proxy_1_1tm__query__proxy__local.html#ad7e3bd6b474cb57a7a985a8c61bd65c2", null ]
];
var classuva_1_1utils_1_1exceptions_1_1_exception =
[
    [ "Exception", "classuva_1_1utils_1_1exceptions_1_1_exception.html#a604280ad919b510e4db6d7d01dcc0c5a", null ],
    [ "Exception", "classuva_1_1utils_1_1exceptions_1_1_exception.html#a4600cc90594ab2ecb849faac33ec473b", null ],
    [ "Exception", "classuva_1_1utils_1_1exceptions_1_1_exception.html#a2c1690463975e76222e80cf34b9dca3c", null ],
    [ "~Exception", "classuva_1_1utils_1_1exceptions_1_1_exception.html#adb3ed0c902ec0851dd27942a61fe7ee4", null ],
    [ "get_message", "classuva_1_1utils_1_1exceptions_1_1_exception.html#a0008575ceece1a6530510f50e44e5457", null ],
    [ "what", "classuva_1_1utils_1_1exceptions_1_1_exception.html#a46e76809444e422626ab7cb2995dc535", null ]
];
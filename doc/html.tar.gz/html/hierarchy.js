var hierarchy =
[
    [ "uva::smt::bpbd::balancer::adapters_manager::adapter_entry", "structuva_1_1smt_1_1bpbd_1_1balancer_1_1adapters__manager_1_1adapter__entry.html", null ],
    [ "uva::smt::bpbd::balancer::adapters_manager", "classuva_1_1smt_1_1bpbd_1_1balancer_1_1adapters__manager.html", null ],
    [ "uva::smt::bpbd::server::lm::dictionary::aword_index", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1dictionary_1_1aword__index.html", [
      [ "uva::smt::bpbd::server::lm::dictionary::basic_word_index", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1dictionary_1_1basic__word__index.html", [
        [ "uva::smt::bpbd::server::lm::dictionary::counting_word_index", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1dictionary_1_1counting__word__index.html", null ]
      ] ],
      [ "uva::smt::bpbd::server::lm::dictionary::hashing_word_index", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1dictionary_1_1hashing__word__index.html", null ],
      [ "uva::smt::bpbd::server::lm::dictionary::optimizing_word_index< sub_word_index_type >", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1dictionary_1_1optimizing__word__index.html", null ]
    ] ],
    [ "uva::smt::bpbd::balancer::balancer_job", "classuva_1_1smt_1_1bpbd_1_1balancer_1_1balancer__job.html", null ],
    [ "uva::smt::bpbd::server::lm::caching::BitmapHashCache", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1caching_1_1_bitmap_hash_cache.html", null ],
    [ "uva::smt::bpbd::server::lm::m_grams::m_gram_id::Byte_M_Gram_Id< TWordIdType >", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1m__gram__id_1_1_byte___m___gram___id.html", null ],
    [ "uva::utils::containers::circular_queue< elem_type, capacity >", "classuva_1_1utils_1_1containers_1_1circular__queue.html", null ],
    [ "uva::smt::bpbd::client::client_parameters_struct", "structuva_1_1smt_1_1bpbd_1_1client_1_1client__parameters__struct.html", null ],
    [ "uva::utils::cmd::cmd_line_base", "classuva_1_1utils_1_1cmd_1_1cmd__line__base.html", [
      [ "uva::smt::bpbd::balancer::balancer_console", "classuva_1_1smt_1_1bpbd_1_1balancer_1_1balancer__console.html", null ],
      [ "uva::smt::bpbd::processor::processor_console", "classuva_1_1smt_1_1bpbd_1_1processor_1_1processor__console.html", null ],
      [ "uva::smt::bpbd::server::server_console", "classuva_1_1smt_1_1bpbd_1_1server_1_1server__console.html", null ]
    ] ],
    [ "uva::utils::cmd::cmd_line_client", "classuva_1_1utils_1_1cmd_1_1cmd__line__client.html", [
      [ "uva::smt::bpbd::balancer::bl_cmd_line_client", "classuva_1_1smt_1_1bpbd_1_1balancer_1_1bl__cmd__line__client.html", [
        [ "uva::smt::bpbd::balancer::balancer_server< TLS_CLASS >", "classuva_1_1smt_1_1bpbd_1_1balancer_1_1balancer__server.html", null ]
      ] ],
      [ "uva::smt::bpbd::processor::processor_server< TLS_CLASS >", "classuva_1_1smt_1_1bpbd_1_1processor_1_1processor__server.html", null ],
      [ "uva::smt::bpbd::server::translation_server< TLS_CLASS >", "classuva_1_1smt_1_1bpbd_1_1server_1_1translation__server.html", null ]
    ] ],
    [ "uva::smt::bpbd::server::decoder::stack::stack_level_templ< is_dist, NUM_WORDS_PER_SENTENCE, MAX_HISTORY_LENGTH, MAX_M_GRAM_QUERY_LENGTH >::const_iterator", "classuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1stack_1_1stack__level__templ_1_1const__iterator.html", null ],
    [ "uva::smt::bpbd::server::decoder::de_configurator", "classuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1de__configurator.html", null ],
    [ "uva::smt::bpbd::server::decoder::de_parameters_struct", "structuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1de__parameters__struct.html", null ],
    [ "uva::utils::containers::dynamic_stack_array< ELEMENT_TYPE, IDX_DATA_TYPE, INITIAL_CAPACITY, DESTRUCTOR >", "classuva_1_1utils_1_1containers_1_1dynamic__stack__array.html", null ],
    [ "uva::utils::containers::dynamic_stack_array< ARRAY_ELEM_TYPE, uint32_t >", "classuva_1_1utils_1_1containers_1_1dynamic__stack__array.html", [
      [ "uva::smt::bpbd::server::lm::w2c_array_trie< WordIndexType >::WordDataEntry< ARRAY_ELEM_TYPE >", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1w2c__array__trie_1_1_word_data_entry.html", null ]
    ] ],
    [ "uva::utils::containers::ordered_list< elem_type >::elem_container", "structuva_1_1utils_1_1containers_1_1ordered__list_1_1elem__container.html", null ],
    [ "uva::utils::containers::ELEMENT_DEALLOC_FUNC< ELEM_TYPE >", "structuva_1_1utils_1_1containers_1_1_e_l_e_m_e_n_t___d_e_a_l_l_o_c___f_u_n_c.html", null ],
    [ "exception", null, [
      [ "uva::utils::exceptions::uva_exception", "classuva_1_1utils_1_1exceptions_1_1uva__exception.html", null ]
    ] ],
    [ "uva::smt::bpbd::server::common::feature_id_registry", "classuva_1_1smt_1_1bpbd_1_1server_1_1common_1_1feature__id__registry.html", null ],
    [ "uva::utils::containers::fixed_size_hashmap< ELEMENT_TYPE, KEY_TYPE, IDX_TYPE >", "classuva_1_1utils_1_1containers_1_1fixed__size__hashmap.html", null ],
    [ "uva::utils::containers::alloc::greedy_memory_allocator< T >", "classuva_1_1utils_1_1containers_1_1alloc_1_1greedy__memory__allocator.html", null ],
    [ "uva::utils::containers::greedy_memory_storage", "classuva_1_1utils_1_1containers_1_1greedy__memory__storage.html", null ],
    [ "uva::utils::id_manager< id_type >", "classuva_1_1utils_1_1id__manager.html", null ],
    [ "uva::utils::id_manager< job_id_type >", "classuva_1_1utils_1_1id__manager.html", null ],
    [ "uva::utils::id_manager< language_uid >", "classuva_1_1utils_1_1id__manager.html", null ],
    [ "uva::utils::id_manager< server_id_type >", "classuva_1_1utils_1_1id__manager.html", null ],
    [ "uva::utils::id_manager< session_id_type >", "classuva_1_1utils_1_1id__manager.html", null ],
    [ "uva::utils::id_manager< task_id_type >", "classuva_1_1utils_1_1id__manager.html", null ],
    [ "uva::smt::bpbd::processor::language_config_struct", "structuva_1_1smt_1_1bpbd_1_1processor_1_1language__config__struct.html", null ],
    [ "uva::smt::bpbd::common::messaging::language_registry", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1language__registry.html", null ],
    [ "uva::utils::threads::task_pool< pool_task >::less_task_priority", "structuva_1_1utils_1_1threads_1_1task__pool_1_1less__task__priority.html", null ],
    [ "uva::smt::bpbd::server::lm::arpa::lm_basic_builder< trie_type, reader_type >", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1arpa_1_1lm__basic__builder.html", null ],
    [ "uva::smt::bpbd::server::lm::lm_configurator", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1lm__configurator.html", null ],
    [ "uva::smt::bpbd::server::lm::__executor::lm_exec_params", "structuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1____executor_1_1lm__exec__params.html", null ],
    [ "uva::smt::bpbd::server::lm::proxy::lm_fast_query_proxy", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1proxy_1_1lm__fast__query__proxy.html", [
      [ "uva::smt::bpbd::server::lm::proxy::lm_fast_query_proxy_local< trie_type >", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1proxy_1_1lm__fast__query__proxy__local.html", null ]
    ] ],
    [ "uva::smt::bpbd::server::lm::arpa::lm_gram_builder< WordIndexType, CURR_LEVEL, is_mult_weight >", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1arpa_1_1lm__gram__builder.html", null ],
    [ "uva::smt::bpbd::server::lm::arpa::lm_gram_builder_factory< TrieType >", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1arpa_1_1lm__gram__builder__factory.html", null ],
    [ "uva::smt::bpbd::server::lm::lm_parameters_struct", "structuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1lm__parameters__struct.html", null ],
    [ "uva::smt::bpbd::server::lm::proxy::lm_proxy", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1proxy_1_1lm__proxy.html", [
      [ "uva::smt::bpbd::server::lm::proxy::lm_proxy_local", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1proxy_1_1lm__proxy__local.html", null ]
    ] ],
    [ "uva::smt::bpbd::server::lm::proxy::lm_slow_query_proxy", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1proxy_1_1lm__slow__query__proxy.html", [
      [ "uva::smt::bpbd::server::lm::proxy::lm_slow_query_proxy_local< trie_type >", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1proxy_1_1lm__slow__query__proxy__local.html", null ]
    ] ],
    [ "uva::utils::logging::logger", "classuva_1_1utils_1_1logging_1_1logger.html", null ],
    [ "uva::utils::logging::logging_synch", "structuva_1_1utils_1_1logging_1_1logging__synch.html", null ],
    [ "uva::smt::bpbd::server::lm::m_grams::m_gram_payload_s", "structuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1m__gram__payload__s.html", null ],
    [ "uva::smt::bpbd::server::lm::m_gram_query", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__gram__query.html", null ],
    [ "uva::utils::containers::mem_increase_strategy", "classuva_1_1utils_1_1containers_1_1mem__increase__strategy.html", null ],
    [ "uva::utils::monitor::memory_usage", "structuva_1_1utils_1_1monitor_1_1memory__usage.html", null ],
    [ "uva::smt::bpbd::common::messaging::msg_base", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1msg__base.html", [
      [ "uva::smt::bpbd::common::messaging::incoming_msg", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1incoming__msg.html", null ],
      [ "uva::smt::bpbd::common::messaging::outgoing_msg", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1outgoing__msg.html", [
        [ "uva::smt::bpbd::client::messaging::proc_req_out", "classuva_1_1smt_1_1bpbd_1_1client_1_1messaging_1_1proc__req__out.html", null ],
        [ "uva::smt::bpbd::client::messaging::supp_lang_req_out", "classuva_1_1smt_1_1bpbd_1_1client_1_1messaging_1_1supp__lang__req__out.html", null ],
        [ "uva::smt::bpbd::client::messaging::trans_job_req_out", "classuva_1_1smt_1_1bpbd_1_1client_1_1messaging_1_1trans__job__req__out.html", null ],
        [ "uva::smt::bpbd::processor::messaging::proc_resp_out", "classuva_1_1smt_1_1bpbd_1_1processor_1_1messaging_1_1proc__resp__out.html", null ],
        [ "uva::smt::bpbd::server::messaging::supp_lang_resp_out", "classuva_1_1smt_1_1bpbd_1_1server_1_1messaging_1_1supp__lang__resp__out.html", null ],
        [ "uva::smt::bpbd::server::messaging::trans_job_resp_out", "classuva_1_1smt_1_1bpbd_1_1server_1_1messaging_1_1trans__job__resp__out.html", null ]
      ] ]
    ] ],
    [ "object", null, [
      [ "post_process_nltk.PostProcessor", "classpost__process__nltk_1_1_post_processor.html", null ]
    ] ],
    [ "uva::utils::containers::ordered_list< elem_type >", "classuva_1_1utils_1_1containers_1_1ordered__list.html", null ],
    [ "uva::smt::bpbd::server::lm::m_grams::phrase_base< MAX_PHRASE_LENGTH, MAX_PHRASE_ID_LENGTH >", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1phrase__base.html", null ],
    [ "uva::smt::bpbd::server::lm::m_grams::phrase_base< MODEL_M_GRAM_MAX_LEN, MODEL_M_GRAM_MAX_LEN >", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1phrase__base.html", [
      [ "uva::smt::bpbd::server::lm::m_grams::model_m_gram", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1model__m__gram.html", null ]
    ] ],
    [ "uva::smt::bpbd::server::lm::m_grams::phrase_base< QUERY_M_GRAM_MAX_LEN, LM_M_GRAM_LEVEL_MAX >", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1phrase__base.html", [
      [ "uva::smt::bpbd::server::lm::m_grams::query_m_gram", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1query__m__gram.html", null ]
    ] ],
    [ "uva::smt::bpbd::server::decoder::sentence::phrase_data_entry", "structuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1sentence_1_1phrase__data__entry.html", null ],
    [ "uva::smt::bpbd::processor::processor_job", "classuva_1_1smt_1_1bpbd_1_1processor_1_1processor__job.html", [
      [ "uva::smt::bpbd::processor::post_proc_job", "classuva_1_1smt_1_1bpbd_1_1processor_1_1post__proc__job.html", null ],
      [ "uva::smt::bpbd::processor::pre_proc_job", "classuva_1_1smt_1_1bpbd_1_1processor_1_1pre__proc__job.html", null ]
    ] ],
    [ "uva::utils::containers::alloc::greedy_memory_allocator< T >::rebind< U >", "structuva_1_1utils_1_1containers_1_1alloc_1_1greedy__memory__allocator_1_1rebind.html", null ],
    [ "uva::smt::bpbd::common::messaging::request_msg", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1request__msg.html", [
      [ "uva::smt::bpbd::common::messaging::proc_req", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1proc__req.html", [
        [ "uva::smt::bpbd::client::messaging::proc_req_out", "classuva_1_1smt_1_1bpbd_1_1client_1_1messaging_1_1proc__req__out.html", null ],
        [ "uva::smt::bpbd::processor::messaging::proc_req_in", "classuva_1_1smt_1_1bpbd_1_1processor_1_1messaging_1_1proc__req__in.html", null ]
      ] ],
      [ "uva::smt::bpbd::common::messaging::supp_lang_req", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1supp__lang__req.html", [
        [ "uva::smt::bpbd::client::messaging::supp_lang_req_out", "classuva_1_1smt_1_1bpbd_1_1client_1_1messaging_1_1supp__lang__req__out.html", null ],
        [ "uva::smt::bpbd::server::messaging::supp_lang_req_in", "classuva_1_1smt_1_1bpbd_1_1server_1_1messaging_1_1supp__lang__req__in.html", null ]
      ] ],
      [ "uva::smt::bpbd::common::messaging::trans_job_req", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1trans__job__req.html", [
        [ "uva::smt::bpbd::client::messaging::trans_job_req_out", "classuva_1_1smt_1_1bpbd_1_1client_1_1messaging_1_1trans__job__req__out.html", null ],
        [ "uva::smt::bpbd::server::messaging::trans_job_req_in", "classuva_1_1smt_1_1bpbd_1_1server_1_1messaging_1_1trans__job__req__in.html", null ]
      ] ]
    ] ],
    [ "uva::smt::bpbd::common::messaging::response_msg", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1response__msg.html", [
      [ "uva::smt::bpbd::common::messaging::proc_resp", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1proc__resp.html", [
        [ "uva::smt::bpbd::client::messaging::proc_resp_in", "classuva_1_1smt_1_1bpbd_1_1client_1_1messaging_1_1proc__resp__in.html", null ],
        [ "uva::smt::bpbd::processor::messaging::proc_resp_out", "classuva_1_1smt_1_1bpbd_1_1processor_1_1messaging_1_1proc__resp__out.html", null ]
      ] ],
      [ "uva::smt::bpbd::common::messaging::supp_lang_resp", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1supp__lang__resp.html", [
        [ "uva::smt::bpbd::client::messaging::supp_lang_resp_in", "classuva_1_1smt_1_1bpbd_1_1client_1_1messaging_1_1supp__lang__resp__in.html", null ],
        [ "uva::smt::bpbd::server::messaging::supp_lang_resp_out", "classuva_1_1smt_1_1bpbd_1_1server_1_1messaging_1_1supp__lang__resp__out.html", null ]
      ] ],
      [ "uva::smt::bpbd::common::messaging::trans_job_resp", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1trans__job__resp.html", [
        [ "uva::smt::bpbd::client::messaging::trans_job_resp_in", "classuva_1_1smt_1_1bpbd_1_1client_1_1messaging_1_1trans__job__resp__in.html", null ],
        [ "uva::smt::bpbd::server::messaging::trans_job_resp_out", "classuva_1_1smt_1_1bpbd_1_1server_1_1messaging_1_1trans__job__resp__out.html", null ]
      ] ],
      [ "uva::smt::bpbd::common::messaging::trans_sent_data", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1trans__sent__data.html", [
        [ "uva::smt::bpbd::client::messaging::trans_sent_data_in", "classuva_1_1smt_1_1bpbd_1_1client_1_1messaging_1_1trans__sent__data__in.html", null ],
        [ "uva::smt::bpbd::server::messaging::trans_sent_data_out", "classuva_1_1smt_1_1bpbd_1_1server_1_1messaging_1_1trans__sent__data__out.html", null ]
      ] ]
    ] ],
    [ "uva::smt::bpbd::server::rm::builders::rm_basic_builder< model_type, reader_type >", "classuva_1_1smt_1_1bpbd_1_1server_1_1rm_1_1builders_1_1rm__basic__builder.html", null ],
    [ "uva::smt::bpbd::server::rm::models::rm_basic_model", "classuva_1_1smt_1_1bpbd_1_1server_1_1rm_1_1models_1_1rm__basic__model.html", null ],
    [ "uva::smt::bpbd::server::rm::rm_configurator", "classuva_1_1smt_1_1bpbd_1_1server_1_1rm_1_1rm__configurator.html", null ],
    [ "uva::smt::bpbd::server::rm::models::rm_entry", "classuva_1_1smt_1_1bpbd_1_1server_1_1rm_1_1models_1_1rm__entry.html", null ],
    [ "uva::smt::bpbd::server::rm::rm_parameters_struct", "structuva_1_1smt_1_1bpbd_1_1server_1_1rm_1_1rm__parameters__struct.html", null ],
    [ "uva::smt::bpbd::server::rm::proxy::rm_proxy", "classuva_1_1smt_1_1bpbd_1_1server_1_1rm_1_1proxy_1_1rm__proxy.html", [
      [ "uva::smt::bpbd::server::rm::proxy::rm_proxy_local", "classuva_1_1smt_1_1bpbd_1_1server_1_1rm_1_1proxy_1_1rm__proxy__local.html", null ]
    ] ],
    [ "uva::smt::bpbd::server::rm::models::rm_query< model_type >", "classuva_1_1smt_1_1bpbd_1_1server_1_1rm_1_1models_1_1rm__query.html", null ],
    [ "uva::smt::bpbd::server::rm::proxy::rm_query_proxy", "classuva_1_1smt_1_1bpbd_1_1server_1_1rm_1_1proxy_1_1rm__query__proxy.html", [
      [ "uva::smt::bpbd::server::rm::proxy::rm_query_proxy_local< model_type >", "classuva_1_1smt_1_1bpbd_1_1server_1_1rm_1_1proxy_1_1rm__query__proxy__local.html", null ]
    ] ],
    [ "uva::smt::bpbd::server::lm::__G2DMapTrie::S_M_GramData< TPayloadType, TWordIdType >", "structuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1_____g2_d_map_trie_1_1_s___m___gram_data.html", null ],
    [ "uva::smt::bpbd::server::lm::__H2DMapTrie::S_M_GramData< TPayloadType >", "structuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1_____h2_d_map_trie_1_1_s___m___gram_data.html", null ],
    [ "uva::smt::bpbd::server::lm::__W2CArrayTrie::S_M_GramData< PAYLOAD_TYPE >", "structuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1_____w2_c_array_trie_1_1_s___m___gram_data.html", null ],
    [ "uva::smt::bpbd::server::decoder::sentence::sentence_decoder", "classuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1sentence_1_1sentence__decoder.html", null ],
    [ "uva::smt::bpbd::common::messaging::websocket::server_hs_with_tls< TLS_MODE >", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1websocket_1_1server__hs__with__tls.html", null ],
    [ "uva::smt::bpbd::common::messaging::websocket::server_hs_without_tls", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1websocket_1_1server__hs__without__tls.html", null ],
    [ "uva::smt::bpbd::balancer::balancer_manager::server_jobs_entry_type", "structuva_1_1smt_1_1bpbd_1_1balancer_1_1balancer__manager_1_1server__jobs__entry__type.html", null ],
    [ "uva::smt::bpbd::processor::processor_manager::session_data_struct", "structuva_1_1smt_1_1bpbd_1_1processor_1_1processor__manager_1_1session__data__struct.html", null ],
    [ "uva::smt::bpbd::common::messaging::session_job_pool_base< job_type >", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1session__job__pool__base.html", null ],
    [ "uva::smt::bpbd::common::messaging::session_job_pool_base< balancer_job >", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1session__job__pool__base.html", [
      [ "uva::smt::bpbd::balancer::balancer_manager", "classuva_1_1smt_1_1bpbd_1_1balancer_1_1balancer__manager.html", null ]
    ] ],
    [ "uva::smt::bpbd::common::messaging::session_job_pool_base< processor_job >", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1session__job__pool__base.html", [
      [ "uva::smt::bpbd::processor::processor_manager", "classuva_1_1smt_1_1bpbd_1_1processor_1_1processor__manager.html", null ]
    ] ],
    [ "uva::smt::bpbd::common::messaging::session_job_pool_base< trans_job >", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1session__job__pool__base.html", [
      [ "uva::smt::bpbd::server::translation_manager", "classuva_1_1smt_1_1bpbd_1_1server_1_1translation__manager.html", null ]
    ] ],
    [ "uva::smt::bpbd::common::messaging::session_manager", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1session__manager.html", [
      [ "uva::smt::bpbd::balancer::balancer_manager", "classuva_1_1smt_1_1bpbd_1_1balancer_1_1balancer__manager.html", null ],
      [ "uva::smt::bpbd::processor::processor_manager", "classuva_1_1smt_1_1bpbd_1_1processor_1_1processor__manager.html", null ],
      [ "uva::smt::bpbd::server::translation_manager", "classuva_1_1smt_1_1bpbd_1_1server_1_1translation__manager.html", null ]
    ] ],
    [ "uva::smt::bpbd::balancer::adapters_manager::source_entry", "structuva_1_1smt_1_1bpbd_1_1balancer_1_1adapters__manager_1_1source__entry.html", null ],
    [ "uva::smt::bpbd::server::decoder::stack::stack_data_templ< is_dist, NUM_WORDS_PER_SENTENCE, MAX_HISTORY_LENGTH, MAX_M_GRAM_QUERY_LENGTH >", "structuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1stack_1_1stack__data__templ.html", null ],
    [ "uva::smt::bpbd::server::decoder::stack::stack_level_templ< is_dist, NUM_WORDS_PER_SENTENCE, MAX_HISTORY_LENGTH, MAX_M_GRAM_QUERY_LENGTH >", "classuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1stack_1_1stack__level__templ.html", null ],
    [ "uva::smt::bpbd::server::decoder::stack::stack_state_templ< is_dist, NUM_WORDS_PER_SENTENCE, MAX_HISTORY_LENGTH, MAX_M_GRAM_QUERY_LENGTH >", "classuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1stack_1_1stack__state__templ.html", null ],
    [ "uva::utils::monitor::stat_monitor", "classuva_1_1utils_1_1monitor_1_1stat__monitor.html", null ],
    [ "uva::smt::bpbd::server::decoder::stack::state_data_templ< is_dist, NUM_WORDS_PER_SENTENCE, MAX_HISTORY_LENGTH, MAX_M_GRAM_QUERY_LENGTH >", "structuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1stack_1_1state__data__templ.html", null ],
    [ "uva::smt::bpbd::common::messaging::status_code", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1status__code.html", null ],
    [ "uva::smt::bpbd::server::lm::m_grams::m_gram_id::T_Gram_Id_Key", "structuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1m__gram__id_1_1_t___gram___id___key.html", null ],
    [ "uva::utils::containers::utils::T_IS_COMPARE_FUNC< ELEM_TYPE >", "structuva_1_1utils_1_1containers_1_1utils_1_1_t___i_s___c_o_m_p_a_r_e___f_u_n_c.html", null ],
    [ "uva::smt::bpbd::server::lm::arpa::TAddGramFunct< WordIndexType >", "structuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1arpa_1_1_t_add_gram_funct.html", null ],
    [ "uva::smt::bpbd::balancer::adapters_manager::target_entry", "structuva_1_1smt_1_1bpbd_1_1balancer_1_1adapters__manager_1_1target__entry.html", null ],
    [ "uva::utils::threads::task_pool< pool_task >", "classuva_1_1utils_1_1threads_1_1task__pool.html", null ],
    [ "uva::utils::threads::task_pool< uva::smt::bpbd::balancer::balancer_job >", "classuva_1_1utils_1_1threads_1_1task__pool.html", null ],
    [ "uva::utils::threads::task_pool< uva::smt::bpbd::processor::processor_job >", "classuva_1_1utils_1_1threads_1_1task__pool.html", null ],
    [ "uva::utils::threads::task_pool< uva::smt::bpbd::server::trans_task >", "classuva_1_1utils_1_1threads_1_1task__pool.html", null ],
    [ "uva::utils::threads::task_pool_worker< pool_task >", "classuva_1_1utils_1_1threads_1_1task__pool__worker.html", null ],
    [ "uva::smt::bpbd::server::lm::__C2WArrayTrie::TCtxIdProbData", "structuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1_____c2_w_array_trie_1_1_t_ctx_id_prob_data.html", null ],
    [ "uva::utils::file::text_piece_reader", "classuva_1_1utils_1_1file_1_1text__piece__reader.html", [
      [ "uva::utils::file::afile_reader", "classuva_1_1utils_1_1file_1_1afile__reader.html", [
        [ "uva::utils::file::cstyle_file_reader", "classuva_1_1utils_1_1file_1_1cstyle__file__reader.html", null ],
        [ "uva::utils::file::file_stream_reader", "classuva_1_1utils_1_1file_1_1file__stream__reader.html", null ],
        [ "uva::utils::file::memory_mapped_file_reader", "classuva_1_1utils_1_1file_1_1memory__mapped__file__reader.html", null ]
      ] ]
    ] ],
    [ "uva::smt::bpbd::server::tm::builders::tm_basic_builder< model_type, reader_type >", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1builders_1_1tm__basic__builder.html", null ],
    [ "uva::smt::bpbd::server::tm::models::tm_basic_model", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1models_1_1tm__basic__model.html", null ],
    [ "uva::smt::bpbd::server::tm::tm_configurator", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1tm__configurator.html", null ],
    [ "uva::smt::bpbd::server::tm::tm_parameters_struct", "structuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1tm__parameters__struct.html", null ],
    [ "uva::smt::bpbd::server::tm::proxy::tm_proxy", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1proxy_1_1tm__proxy.html", [
      [ "uva::smt::bpbd::server::tm::proxy::tm_proxy_local", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1proxy_1_1tm__proxy__local.html", null ]
    ] ],
    [ "uva::smt::bpbd::server::tm::models::tm_query< model_type >", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1models_1_1tm__query.html", null ],
    [ "uva::smt::bpbd::server::tm::proxy::tm_query_proxy", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1proxy_1_1tm__query__proxy.html", [
      [ "uva::smt::bpbd::server::tm::proxy::tm_query_proxy_local< model_type >", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1proxy_1_1tm__query__proxy__local.html", null ]
    ] ],
    [ "uva::smt::bpbd::server::tm::models::tm_source_entry", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1models_1_1tm__source__entry.html", null ],
    [ "uva::smt::bpbd::server::tm::models::tm_target_entry", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1models_1_1tm__target__entry.html", [
      [ "uva::smt::bpbd::server::tm::models::tm_tmp_target_entry", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1models_1_1tm__tmp__target__entry.html", null ]
    ] ],
    [ "uva::smt::bpbd::server::trans_info_provider", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__info__provider.html", [
      [ "uva::smt::bpbd::server::decoder::stack::multi_stack_templ< is_dist, NUM_WORDS_PER_SENTENCE, MAX_HISTORY_LENGTH, MAX_M_GRAM_QUERY_LENGTH >", "classuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1stack_1_1multi__stack__templ.html", null ]
    ] ],
    [ "uva::smt::bpbd::client::trans_job", "structuva_1_1smt_1_1bpbd_1_1client_1_1trans__job.html", null ],
    [ "uva::smt::bpbd::server::trans_job", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__job.html", null ],
    [ "uva::smt::bpbd::client::trans_job_status", "classuva_1_1smt_1_1bpbd_1_1client_1_1trans__job__status.html", null ],
    [ "uva::smt::bpbd::server::trans_task", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__task.html", null ],
    [ "uva::smt::bpbd::server::lm::c2w_array_trie< WordIndexType >::TSubArrReference", "structuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1c2w__array__trie_1_1_t_sub_arr_reference.html", null ],
    [ "uva::smt::bpbd::server::lm::__C2WArrayTrie::TWordIdPBData", "structuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1_____c2_w_array_trie_1_1_t_word_id_p_b_data.html", null ],
    [ "uva::smt::bpbd::server::lm::dictionary::__counting_word_index::TWordInfo", "structuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1dictionary_1_1____counting__word__index_1_1_t_word_info.html", null ],
    [ "uva::utils::containers::upp_diag_matrix< element_type >", "classuva_1_1utils_1_1containers_1_1upp__diag__matrix.html", null ],
    [ "uva::utils::containers::upp_diag_matrix< phrase_data_entry >", "classuva_1_1utils_1_1containers_1_1upp__diag__matrix.html", null ],
    [ "uva::smt::bpbd::server::lm::W2CH_UM_Storage", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1_w2_c_h___u_m___storage.html", null ],
    [ "uva::smt::bpbd::server::lm::W2CH_UM_StorageFactory< N >", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1_w2_c_h___u_m___storage_factory.html", null ],
    [ "uva::smt::bpbd::common::messaging::websocket::websocket_client", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1websocket_1_1websocket__client.html", [
      [ "uva::smt::bpbd::common::messaging::websocket::websocket_client_base< ASIO_CONFIG >", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1websocket_1_1websocket__client__base.html", null ],
      [ "uva::smt::bpbd::common::messaging::websocket::websocket_client_with_tls< TLS_MODE >", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1websocket_1_1websocket__client__with__tls.html", null ],
      [ "uva::smt::bpbd::common::messaging::websocket::websocket_client_base< websocketpp::config::asio_tls_client >", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1websocket_1_1websocket__client__base.html", [
        [ "uva::smt::bpbd::common::messaging::websocket::websocket_client_with_tls< TLS_MODE >", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1websocket_1_1websocket__client__with__tls.html", null ]
      ] ]
    ] ],
    [ "uva::smt::bpbd::common::messaging::websocket::websocket_client_creator", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1websocket_1_1websocket__client__creator.html", [
      [ "uva::smt::bpbd::balancer::translator_adapter", "classuva_1_1smt_1_1bpbd_1_1balancer_1_1translator__adapter.html", null ],
      [ "uva::smt::bpbd::client::client_manager< MSG_TYPE, RESPONSE_TYPE >", "classuva_1_1smt_1_1bpbd_1_1client_1_1client__manager.html", null ]
    ] ],
    [ "websocket_client_creator", null, [
      [ "uva::smt::bpbd::client::client_manager< MSG_TYPE, proc_resp_in >", "classuva_1_1smt_1_1bpbd_1_1client_1_1client__manager.html", [
        [ "uva::smt::bpbd::client::proc_manager< msg_type::MESSAGE_POST_PROC_JOB_RESP >", "classuva_1_1smt_1_1bpbd_1_1client_1_1proc__manager.html", [
          [ "uva::smt::bpbd::client::post_proc_manager", "classuva_1_1smt_1_1bpbd_1_1client_1_1post__proc__manager.html", null ]
        ] ],
        [ "uva::smt::bpbd::client::proc_manager< msg_type::MESSAGE_PRE_PROC_JOB_RESP >", "classuva_1_1smt_1_1bpbd_1_1client_1_1proc__manager.html", [
          [ "uva::smt::bpbd::client::pre_proc_manager", "classuva_1_1smt_1_1bpbd_1_1client_1_1pre__proc__manager.html", null ]
        ] ],
        [ "uva::smt::bpbd::client::proc_manager< MSG_TYPE >", "classuva_1_1smt_1_1bpbd_1_1client_1_1proc__manager.html", null ]
      ] ],
      [ "uva::smt::bpbd::client::client_manager< msg_type::MESSAGE_TRANS_JOB_RESP, trans_job_resp_in >", "classuva_1_1smt_1_1bpbd_1_1client_1_1client__manager.html", [
        [ "uva::smt::bpbd::client::trans_manager", "classuva_1_1smt_1_1bpbd_1_1client_1_1trans__manager.html", null ]
      ] ]
    ] ],
    [ "uva::smt::bpbd::common::messaging::websocket::websocket_client_params_struct", "structuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1websocket_1_1websocket__client__params__struct.html", [
      [ "uva::smt::bpbd::balancer::translator_config_struct", "structuva_1_1smt_1_1bpbd_1_1balancer_1_1translator__config__struct.html", null ]
    ] ],
    [ "uva::smt::bpbd::common::messaging::websocket_server< TLS_CLASS >", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1websocket__server.html", [
      [ "uva::smt::bpbd::balancer::balancer_server< TLS_CLASS >", "classuva_1_1smt_1_1bpbd_1_1balancer_1_1balancer__server.html", null ],
      [ "uva::smt::bpbd::processor::processor_server< TLS_CLASS >", "classuva_1_1smt_1_1bpbd_1_1processor_1_1processor__server.html", null ],
      [ "uva::smt::bpbd::server::translation_server< TLS_CLASS >", "classuva_1_1smt_1_1bpbd_1_1server_1_1translation__server.html", null ]
    ] ],
    [ "uva::smt::bpbd::common::messaging::websocket::websocket_server_params_struct", "structuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1websocket_1_1websocket__server__params__struct.html", [
      [ "uva::smt::bpbd::balancer::balancer_parameters_struct", "structuva_1_1smt_1_1bpbd_1_1balancer_1_1balancer__parameters__struct.html", null ],
      [ "uva::smt::bpbd::processor::processor_parameters_struct", "structuva_1_1smt_1_1bpbd_1_1processor_1_1processor__parameters__struct.html", null ],
      [ "uva::smt::bpbd::server::server_parameters_struct", "structuva_1_1smt_1_1bpbd_1_1server_1_1server__parameters__struct.html", null ]
    ] ],
    [ "uva::smt::bpbd::server::lm::dictionary::__optimizing_word_index::word_index_bucket_entry< word_id_type >", "structuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1dictionary_1_1____optimizing__word__index_1_1word__index__bucket__entry.html", null ],
    [ "uva::smt::bpbd::server::lm::word_index_trie_base< WordIndex >", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1word__index__trie__base.html", null ],
    [ "uva::smt::bpbd::server::lm::word_index_trie_base< lm_word_index >", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1word__index__trie__base.html", [
      [ "uva::smt::bpbd::server::lm::generic_trie_base< h2d_map_trie< lm_word_index >, lm_word_index, __H2DMapTrie::BITMAP_HASH_CACHE_BUCKETS_FACTOR >", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1generic__trie__base.html", [
        [ "uva::smt::bpbd::server::lm::h2d_map_trie< lm_word_index >", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1h2d__map__trie.html", null ]
      ] ]
    ] ],
    [ "uva::smt::bpbd::server::lm::word_index_trie_base< WordIndexType >", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1word__index__trie__base.html", [
      [ "uva::smt::bpbd::server::lm::generic_trie_base< c2d_hybrid_trie< WordIndexType >, WordIndexType, BITMAP_HASH_CACHE_BUCKETS_FACTOR >", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1generic__trie__base.html", [
        [ "uva::smt::bpbd::server::lm::layered_trie_base< c2d_hybrid_trie< WordIndexType >, WordIndexType, __C2DHybridTrie::BITMAP_HASH_CACHE_BUCKETS_FACTOR >", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1layered__trie__base.html", [
          [ "uva::smt::bpbd::server::lm::c2d_hybrid_trie< WordIndexType >", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1c2d__hybrid__trie.html", null ]
        ] ]
      ] ],
      [ "uva::smt::bpbd::server::lm::generic_trie_base< c2d_map_trie< WordIndexType >, WordIndexType, BITMAP_HASH_CACHE_BUCKETS_FACTOR >", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1generic__trie__base.html", [
        [ "uva::smt::bpbd::server::lm::layered_trie_base< c2d_map_trie< WordIndexType >, WordIndexType, __C2DMapTrie::BITMAP_HASH_CACHE_BUCKETS_FACTOR >", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1layered__trie__base.html", [
          [ "uva::smt::bpbd::server::lm::c2d_map_trie< WordIndexType >", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1c2d__map__trie.html", null ]
        ] ]
      ] ],
      [ "uva::smt::bpbd::server::lm::generic_trie_base< c2w_array_trie< WordIndexType >, WordIndexType, BITMAP_HASH_CACHE_BUCKETS_FACTOR >", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1generic__trie__base.html", [
        [ "uva::smt::bpbd::server::lm::layered_trie_base< c2w_array_trie< WordIndexType >, WordIndexType, __C2WArrayTrie::BITMAP_HASH_CACHE_BUCKETS_FACTOR >", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1layered__trie__base.html", [
          [ "uva::smt::bpbd::server::lm::c2w_array_trie< WordIndexType >", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1c2w__array__trie.html", null ]
        ] ]
      ] ],
      [ "uva::smt::bpbd::server::lm::generic_trie_base< g2d_map_trie< WordIndexType >, WordIndexType, __G2DMapTrie::BITMAP_HASH_CACHE_BUCKETS_FACTOR >", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1generic__trie__base.html", [
        [ "uva::smt::bpbd::server::lm::g2d_map_trie< WordIndexType >", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1g2d__map__trie.html", null ]
      ] ],
      [ "uva::smt::bpbd::server::lm::generic_trie_base< h2d_map_trie< WordIndexType >, WordIndexType, __H2DMapTrie::BITMAP_HASH_CACHE_BUCKETS_FACTOR >", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1generic__trie__base.html", [
        [ "uva::smt::bpbd::server::lm::h2d_map_trie< WordIndexType >", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1h2d__map__trie.html", null ]
      ] ],
      [ "uva::smt::bpbd::server::lm::generic_trie_base< w2c_array_trie< WordIndexType >, WordIndexType, BITMAP_HASH_CACHE_BUCKETS_FACTOR >", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1generic__trie__base.html", [
        [ "uva::smt::bpbd::server::lm::layered_trie_base< w2c_array_trie< WordIndexType >, WordIndexType, __W2CArrayTrie::BITMAP_HASH_CACHE_BUCKETS_FACTOR >", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1layered__trie__base.html", [
          [ "uva::smt::bpbd::server::lm::w2c_array_trie< WordIndexType >", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1w2c__array__trie.html", null ]
        ] ]
      ] ],
      [ "uva::smt::bpbd::server::lm::generic_trie_base< w2c_hybrid_trie< WordIndexType, StorageFactory, StorageContainer >, WordIndexType, BITMAP_HASH_CACHE_BUCKETS_FACTOR >", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1generic__trie__base.html", [
        [ "uva::smt::bpbd::server::lm::layered_trie_base< w2c_hybrid_trie< WordIndexType, StorageFactory, StorageContainer >, WordIndexType, __W2CHybridTrie::BITMAP_HASH_CACHE_BUCKETS_FACTOR >", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1layered__trie__base.html", [
          [ "uva::smt::bpbd::server::lm::w2c_hybrid_trie< WordIndexType, StorageFactory, StorageContainer >", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1w2c__hybrid__trie.html", null ]
        ] ]
      ] ],
      [ "uva::smt::bpbd::server::lm::generic_trie_base< TrieType, WordIndexType, BITMAP_HASH_CACHE_BUCKETS_FACTOR >", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1generic__trie__base.html", [
        [ "uva::smt::bpbd::server::lm::layered_trie_base< TrieType, WordIndexType, BITMAP_HASH_CACHE_BUCKETS_FACTOR >", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1layered__trie__base.html", null ]
      ] ]
    ] ]
];
var classuva_1_1smt_1_1bpbd_1_1client_1_1proc__manager =
[
    [ "request_creator", "classuva_1_1smt_1_1bpbd_1_1client_1_1proc__manager.html#a9e4803c3350a8b527457430b4bc78a4a", null ],
    [ "proc_manager", "classuva_1_1smt_1_1bpbd_1_1client_1_1proc__manager.html#ae2bacf137a81f1e4ae6190401e821d12", null ],
    [ "~proc_manager", "classuva_1_1smt_1_1bpbd_1_1client_1_1proc__manager.html#a95b04b0d78be020d856ddcd925f17789", null ],
    [ "get_act_num_req", "classuva_1_1smt_1_1bpbd_1_1client_1_1proc__manager.html#a652da7a3d10d7a2d0bfbbbc614799c2b", null ],
    [ "get_exp_num_resp", "classuva_1_1smt_1_1bpbd_1_1client_1_1proc__manager.html#a2d793dee77c2f808c481657784af7014", null ],
    [ "process_results", "classuva_1_1smt_1_1bpbd_1_1client_1_1proc__manager.html#ade3998a575bfc93703b24b6882ee5ac9", null ],
    [ "send_job_requests", "classuva_1_1smt_1_1bpbd_1_1client_1_1proc__manager.html#a65fe9171b470f88456851f8f34cf1266", null ],
    [ "set_job_response", "classuva_1_1smt_1_1bpbd_1_1client_1_1proc__manager.html#ad5b6091a95c91088401eeaddef062ee6", null ]
];
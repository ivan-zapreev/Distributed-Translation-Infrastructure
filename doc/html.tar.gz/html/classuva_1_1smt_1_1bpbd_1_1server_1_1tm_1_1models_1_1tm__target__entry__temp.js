var classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1models_1_1tm__target__entry__temp =
[
    [ "tm_target_entry_temp", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1models_1_1tm__target__entry__temp.html#a10d254c10a6cdeb7b5538d2fc1f29a96", null ],
    [ "~tm_target_entry_temp", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1models_1_1tm__target__entry__temp.html#a07f3364da42bd07d8692ceefa95a60b3", null ],
    [ "get_num_words", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1models_1_1tm__target__entry__temp.html#ad2a6ad83bb757e9eb4f229cd8fbbf3c1", null ],
    [ "get_st_uid", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1models_1_1tm__target__entry__temp.html#a321df85fef6d385d5edc0afce9296045", null ],
    [ "get_t_c_s", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1models_1_1tm__target__entry__temp.html#ad971b065528c5763c4fb386db1a688b1", null ],
    [ "get_target_phrase", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1models_1_1tm__target__entry__temp.html#a89fd2815eb087a9abb47040d842597ce", null ],
    [ "get_total_weight", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1models_1_1tm__target__entry__temp.html#ae6c8b88c36a4eeb73926291688df1774", null ],
    [ "get_word_ids", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1models_1_1tm__target__entry__temp.html#adc2c72a44fecd698961cf8f2fcc4bb2e", null ],
    [ "is_unk_trans", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1models_1_1tm__target__entry__temp.html#ae3569c030f9ddb80f02912f4f4ba724c", null ],
    [ "set_data", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1models_1_1tm__target__entry__temp.html#a019f83ab32f5b2b1c5becda8a0596732", null ],
    [ "set_features", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1models_1_1tm__target__entry__temp.html#a71842af251358e437e4d1f8c98b62528", null ]
];
var classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1model__m__gram =
[
    [ "BASE", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1model__m__gram.html#a4089a31decb5c2b1afe81e02043543c7", null ],
    [ "model_m_gram", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1model__m__gram.html#a8a567c654f739ce36458ee07f2f279fd", null ],
    [ "get_hash", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1model__m__gram.html#a47090d51e7dcdaf09369b1fb5db1a177", null ],
    [ "get_next_new_token", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1model__m__gram.html#a60ee2deb3db4eef86abb1ff51caf5d46", null ],
    [ "is_sentence_begin", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1model__m__gram.html#af1d97e7fe0208a73e706fb2d1c6aaeea", null ],
    [ "is_unk_unigram", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1model__m__gram.html#ab0540761af70696cbe32fab24c88d947", null ],
    [ "prepare_for_adding", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1model__m__gram.html#aa4d16455853e9440de0f54749dcd73fd", null ],
    [ "start_new_m_gram", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1model__m__gram.html#ad9ee622d6f170d9b149b23f71fe95fdf", null ],
    [ "operator<<", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1model__m__gram.html#a88dcc7add3f2f6872e082e68d7cd88a2", null ],
    [ "m_payload", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1m__grams_1_1model__m__gram.html#acc7ca63db888d6daa71662c412398ebd", null ]
];
var classasio_1_1detail_1_1strand__service =
[
    [ "on_dispatch_exit", "structasio_1_1detail_1_1strand__service_1_1on__dispatch__exit.html", "structasio_1_1detail_1_1strand__service_1_1on__dispatch__exit" ],
    [ "on_do_complete_exit", "structasio_1_1detail_1_1strand__service_1_1on__do__complete__exit.html", "structasio_1_1detail_1_1strand__service_1_1on__do__complete__exit" ],
    [ "strand_impl", "classasio_1_1detail_1_1strand__service_1_1strand__impl.html", "classasio_1_1detail_1_1strand__service_1_1strand__impl" ],
    [ "implementation_type", "classasio_1_1detail_1_1strand__service.html#ae3f87cc0ee8977c0ed0ee8e35ebe2491", null ],
    [ "strand_service", "classasio_1_1detail_1_1strand__service.html#adf6d552bb6c3c29769a3470d4195593e", null ],
    [ "construct", "classasio_1_1detail_1_1strand__service.html#abe92af2b27d8817a56396308bf644aa8", null ],
    [ "dispatch", "classasio_1_1detail_1_1strand__service.html#a912c9183e381329b109e89f9e54db11f", null ],
    [ "post", "classasio_1_1detail_1_1strand__service.html#a9e5dd38161d27517558096d433df5c2d", null ],
    [ "running_in_this_thread", "classasio_1_1detail_1_1strand__service.html#a0206f4dfeb98dd56a40079d8667ec701", null ],
    [ "shutdown_service", "classasio_1_1detail_1_1strand__service.html#a8d0cfe4d8d6d5f3fd75f968157992644", null ]
];
var classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1c2w__array__trie =
[
    [ "TSubArrReference", "structuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1c2w__array__trie_1_1_t_sub_arr_reference.html", "structuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1c2w__array__trie_1_1_t_sub_arr_reference" ],
    [ "BASE", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1c2w__array__trie.html#a8897c17fb2c7a3bbd1baa91630f886c7", null ],
    [ "TCtxIdProbEntry", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1c2w__array__trie.html#a1240bfbdc6bbb632c56970ae4d6acf91", null ],
    [ "TWordIdPBEntry", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1c2w__array__trie.html#aa01859d7132d0da6ca72acacb42f9762", null ],
    [ "c2w_array_trie", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1c2w__array__trie.html#a2f65e7a797b83bf855ffe24a60f6ecbf", null ],
    [ "~c2w_array_trie", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1c2w__array__trie.html#aa6b5ffd0fa902f0c79c750e109a4c881", null ],
    [ "add_m_gram", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1c2w__array__trie.html#a8bfd215aa7204721868fc9fff3dc12ed", null ],
    [ "get_ctx_id", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1c2w__array__trie.html#a76ee8b0bd14bee3430271c2b4b724dc9", null ],
    [ "get_m_gram_payload", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1c2w__array__trie.html#aa72798c688fe41438024f6620e68d0c9", null ],
    [ "get_n_gram_payload", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1c2w__array__trie.html#aadeccaf603d3d9ae0c4f5f99db252f30", null ],
    [ "get_unigram_payload", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1c2w__array__trie.html#a00b9ca02069871c5a412146ac232a9c2", null ],
    [ "get_unk_word_prob", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1c2w__array__trie.html#aaa984f4a288c6dc1bb3e9e77834b01c7", null ],
    [ "is_post_grams", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1c2w__array__trie.html#a38b623ad6bb56e05dfd0ccf1951cac0a", null ],
    [ "log_model_type_info", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1c2w__array__trie.html#ab34950501079f4e4eb612c5afe20e694", null ],
    [ "post_grams", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1c2w__array__trie.html#afe108069b67b7b0a2a814e07cbfc1304", null ],
    [ "post_m_grams", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1c2w__array__trie.html#a510b3630b20daff118835897c0b1b663", null ],
    [ "post_n_grams", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1c2w__array__trie.html#a0e91aa925a3f84b2444adc9f7d8fe9bb", null ],
    [ "pre_allocate", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1c2w__array__trie.html#a81439cb205ceb202279c395e15dc4c8e", null ],
    [ "set_def_unk_word_prob", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1c2w__array__trie.html#ac955b8d0f0bcfb7727cc9f328bfdedd9", null ]
];
var classuva_1_1smt_1_1bpbd_1_1server_1_1translation__server =
[
    [ "server", "classuva_1_1smt_1_1bpbd_1_1server_1_1translation__server.html#a7a3d55d39330bc8414d5c0964c8e5bd7", null ],
    [ "translation_server", "classuva_1_1smt_1_1bpbd_1_1server_1_1translation__server.html#a3f8206303fa38e30dbd84fa8801e2e2e", null ],
    [ "on_close", "classuva_1_1smt_1_1bpbd_1_1server_1_1translation__server.html#ac458534555d855f68799ca675f612bc5", null ],
    [ "on_fail", "classuva_1_1smt_1_1bpbd_1_1server_1_1translation__server.html#ac26c124f12bc61c9a989e1c899b010ca", null ],
    [ "on_message", "classuva_1_1smt_1_1bpbd_1_1server_1_1translation__server.html#ac3def6980110c67b945d2483a2734630", null ],
    [ "on_open", "classuva_1_1smt_1_1bpbd_1_1server_1_1translation__server.html#aba474a4a531b53d047d0325c0547090a", null ],
    [ "report_run_time_info", "classuva_1_1smt_1_1bpbd_1_1server_1_1translation__server.html#a0c987a4eb353484a89f6b54c44e4940b", null ],
    [ "run", "classuva_1_1smt_1_1bpbd_1_1server_1_1translation__server.html#a16dcf58e027baa12eec503b2323a8131", null ],
    [ "send_response", "classuva_1_1smt_1_1bpbd_1_1server_1_1translation__server.html#a57a29ff74e1ed45b04ad70eca4cb81dd", null ],
    [ "set_num_threads", "classuva_1_1smt_1_1bpbd_1_1server_1_1translation__server.html#a777df696ef2e9bb24fe19b4bff7b7e81", null ],
    [ "stop", "classuva_1_1smt_1_1bpbd_1_1server_1_1translation__server.html#a49a359715e8314937625e44c85d79c25", null ]
];
var classuva_1_1smt_1_1bpbd_1_1server_1_1translation__server =
[
    [ "translation_server", "classuva_1_1smt_1_1bpbd_1_1server_1_1translation__server.html#ab289d41275637cb41b2fdd3a3e360f15", null ],
    [ "after_stop_listening", "classuva_1_1smt_1_1bpbd_1_1server_1_1translation__server.html#ad6dd70b74542942d82b0ba6d3473d060", null ],
    [ "check_source_target_languages", "classuva_1_1smt_1_1bpbd_1_1server_1_1translation__server.html#a834f693614c2e4e328f7a5218c67e945", null ],
    [ "close_session", "classuva_1_1smt_1_1bpbd_1_1server_1_1translation__server.html#a4c02b0dc5543637a66ecf39e362fb648", null ],
    [ "language_request", "classuva_1_1smt_1_1bpbd_1_1server_1_1translation__server.html#a105bcb7d47efc83274c9fb2b0bd8907b", null ],
    [ "open_session", "classuva_1_1smt_1_1bpbd_1_1server_1_1translation__server.html#a66fe267fdd3639c4f5119130011f9266", null ],
    [ "report_run_time_info", "classuva_1_1smt_1_1bpbd_1_1server_1_1translation__server.html#a0c987a4eb353484a89f6b54c44e4940b", null ],
    [ "set_num_threads", "classuva_1_1smt_1_1bpbd_1_1server_1_1translation__server.html#a777df696ef2e9bb24fe19b4bff7b7e81", null ],
    [ "translation_request", "classuva_1_1smt_1_1bpbd_1_1server_1_1translation__server.html#aa888829a2ac989325cddbe0092b9bf4b", null ]
];
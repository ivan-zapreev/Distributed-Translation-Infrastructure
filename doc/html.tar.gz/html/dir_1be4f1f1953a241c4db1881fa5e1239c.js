var dir_1be4f1f1953a241c4db1881fa5e1239c =
[
    [ "common", "dir_dc465ddd09698169e2cf2f449347e8a9.html", "dir_dc465ddd09698169e2cf2f449347e8a9" ],
    [ "decoder", "dir_47557767223151fabc47a8de212b4fca.html", "dir_47557767223151fabc47a8de212b4fca" ],
    [ "lm", "dir_84969bf1e7c5234f2c86b3f12f52e743.html", "dir_84969bf1e7c5234f2c86b3f12f52e743" ],
    [ "messaging", "dir_ff3e5ab7a6c3c551478c1e367a77caed.html", "dir_ff3e5ab7a6c3c551478c1e367a77caed" ],
    [ "rm", "dir_9b850c576ac0f461f372b359b3c6470c.html", "dir_9b850c576ac0f461f372b359b3c6470c" ],
    [ "tm", "dir_b7690412fdeec8e03fb8f001f4a11a3d.html", "dir_b7690412fdeec8e03fb8f001f4a11a3d" ],
    [ "server_configs.hpp", "server__configs_8hpp.html", "server__configs_8hpp" ],
    [ "server_console.hpp", "server__console_8hpp.html", "server__console_8hpp" ],
    [ "server_consts.hpp", "server__consts_8hpp.html", "server__consts_8hpp" ],
    [ "server_parameters.hpp", "server__parameters_8hpp.html", "server__parameters_8hpp" ],
    [ "trans_info_provider.hpp", "trans__info__provider_8hpp.html", [
      [ "trans_info_provider", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__info__provider.html", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__info__provider" ]
    ] ],
    [ "trans_job.hpp", "server_2trans__job_8hpp.html", "server_2trans__job_8hpp" ],
    [ "trans_task.hpp", "trans__task_8hpp.html", "trans__task_8hpp" ],
    [ "trans_task_id.hpp", "trans__task__id_8hpp.html", "trans__task__id_8hpp" ],
    [ "translation_manager.hpp", "translation__manager_8hpp.html", [
      [ "translation_manager", "classuva_1_1smt_1_1bpbd_1_1server_1_1translation__manager.html", "classuva_1_1smt_1_1bpbd_1_1server_1_1translation__manager" ]
    ] ],
    [ "translation_server.hpp", "translation__server_8hpp.html", [
      [ "translation_server", "classuva_1_1smt_1_1bpbd_1_1server_1_1translation__server.html", "classuva_1_1smt_1_1bpbd_1_1server_1_1translation__server" ]
    ] ]
];
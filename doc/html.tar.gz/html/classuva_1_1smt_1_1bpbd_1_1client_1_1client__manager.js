var classuva_1_1smt_1_1bpbd_1_1client_1_1client__manager =
[
    [ "client_manager", "classuva_1_1smt_1_1bpbd_1_1client_1_1client__manager.html#a2eaa4e9acd0cf489d0c5f722055ad756", null ],
    [ "~client_manager", "classuva_1_1smt_1_1bpbd_1_1client_1_1client__manager.html#ab110986c3ba6dfb5d6ec2fe863d5bfcf", null ],
    [ "check_jobs_done_and_notify", "classuva_1_1smt_1_1bpbd_1_1client_1_1client__manager.html#a7f8e274ccf886a41ec84d15f4dbebadb", null ],
    [ "get_act_num_req", "classuva_1_1smt_1_1bpbd_1_1client_1_1client__manager.html#ab0eb1d0f7863ffa300205e59a4c6c364", null ],
    [ "get_exp_num_resp", "classuva_1_1smt_1_1bpbd_1_1client_1_1client__manager.html#a07b06f4f24bb092a145467a77f475adc", null ],
    [ "is_stopping", "classuva_1_1smt_1_1bpbd_1_1client_1_1client__manager.html#a21b00112aa1e93cd6625fb04e3dfaf27", null ],
    [ "notify_conn_closed", "classuva_1_1smt_1_1bpbd_1_1client_1_1client__manager.html#abdee83cac6fc1e4e5db753de543e7b29", null ],
    [ "notify_jobs_done", "classuva_1_1smt_1_1bpbd_1_1client_1_1client__manager.html#a1bb3a75837a6102cd056c2b15540360d", null ],
    [ "notify_jobs_sent", "classuva_1_1smt_1_1bpbd_1_1client_1_1client__manager.html#aeecba08d879acf5b005847906306b191", null ],
    [ "notify_new_msg", "classuva_1_1smt_1_1bpbd_1_1client_1_1client__manager.html#adfbbbf96fce86945f1fa0396b37bc39e", null ],
    [ "process_results", "classuva_1_1smt_1_1bpbd_1_1client_1_1client__manager.html#ac68ac2f5bd2976d64eb9b980352a007f", null ],
    [ "send_job_requests", "classuva_1_1smt_1_1bpbd_1_1client_1_1client__manager.html#a9c4d53fc8819f61bd45720e8dbd0bac7", null ],
    [ "send_requests", "classuva_1_1smt_1_1bpbd_1_1client_1_1client__manager.html#a9996307f7a9c6b1019e9dca4995488a2", null ],
    [ "set_job_response", "classuva_1_1smt_1_1bpbd_1_1client_1_1client__manager.html#a16c39c8bd8f1ca9fd8732f154b338674", null ],
    [ "start", "classuva_1_1smt_1_1bpbd_1_1client_1_1client__manager.html#a94c690ccd299331ed1458b61a3b26e00", null ],
    [ "stop", "classuva_1_1smt_1_1bpbd_1_1client_1_1client__manager.html#a01607bea5581bc60b1f5689b294c87b0", null ],
    [ "wait", "classuva_1_1smt_1_1bpbd_1_1client_1_1client__manager.html#a2b54365f8eacc8d11be09999559710ed", null ]
];
var bpbd__client_8cpp =
[
    [ "PROGRAM_VERSION_STR", "bpbd__client_8cpp.html#a7b840156050051a42341fb349765bba9", null ],
    [ "create_arguments_parser", "bpbd__client_8cpp.html#ae33bb4ba4438f5eb49aa5537fcd20bce", null ],
    [ "destroy_arguments_parser", "bpbd__client_8cpp.html#a865eae59e487cdcab1b549cc29b01ae6", null ],
    [ "main", "bpbd__client_8cpp.html#a3c04138a5bfe5d72780bb7e82a18e627", null ]
];
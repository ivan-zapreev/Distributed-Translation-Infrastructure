var bpbd__client_8cpp =
[
    [ "stringstream_ptr", "bpbd__client_8cpp.html#ad3c693bf80fac808d7307e4c753934e6", null ],
    [ "create_arguments_parser", "bpbd__client_8cpp.html#ae33bb4ba4438f5eb49aa5537fcd20bce", null ],
    [ "destroy_arguments_parser", "bpbd__client_8cpp.html#a865eae59e487cdcab1b549cc29b01ae6", null ],
    [ "get_job_token", "bpbd__client_8cpp.html#a3f32f544d026545cca88165fd3ead16c", null ],
    [ "main", "bpbd__client_8cpp.html#a3c04138a5bfe5d72780bb7e82a18e627", null ],
    [ "post_process", "bpbd__client_8cpp.html#ac5c87f8d1ea12660ce2b7fd8a3797275", null ],
    [ "pre_process", "bpbd__client_8cpp.html#a43ec1e9db58ff4306ce76a49e9fcfbe4", null ],
    [ "read_input", "bpbd__client_8cpp.html#ab06b64ac3cbf409d8acd104efc17ccb5", null ],
    [ "translate", "bpbd__client_8cpp.html#a52d2b7b51e8c7a981ef913c737efee92", null ],
    [ "write_output", "bpbd__client_8cpp.html#a8691e5e5929dba84fd56dce1403f1aa9", null ]
];
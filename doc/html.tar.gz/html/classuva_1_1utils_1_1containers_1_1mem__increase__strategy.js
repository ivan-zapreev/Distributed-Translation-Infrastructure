var classuva_1_1utils_1_1containers_1_1mem__increase__strategy =
[
    [ "mem_increase_strategy", "classuva_1_1utils_1_1containers_1_1mem__increase__strategy.html#ae4f60525eebcba5fe62e871fb91b3d2d", null ],
    [ "mem_increase_strategy", "classuva_1_1utils_1_1containers_1_1mem__increase__strategy.html#a912249f9c54674d2963a56069ae2733c", null ],
    [ "mem_increase_strategy", "classuva_1_1utils_1_1containers_1_1mem__increase__strategy.html#adf5440cfd95aafb6551e846321b3c764", null ],
    [ "get_new_capacity", "classuva_1_1utils_1_1containers_1_1mem__increase__strategy.html#a35282eca175b4d34dae20dd77390ab8a", null ],
    [ "get_strategy_info", "classuva_1_1utils_1_1containers_1_1mem__increase__strategy.html#a139b7e3cc3231660800f698625c875bd", null ]
];
var buffers__iterator_8hpp =
[
    [ "buffers_iterator_types_helper", "structasio_1_1detail_1_1buffers__iterator__types__helper.html", null ],
    [ "buffers_iterator_types_helper< false >", "structasio_1_1detail_1_1buffers__iterator__types__helper_3_01false_01_4.html", "structasio_1_1detail_1_1buffers__iterator__types__helper_3_01false_01_4" ],
    [ "byte_type", "structasio_1_1detail_1_1buffers__iterator__types__helper_3_01false_01_4_1_1byte__type.html", "structasio_1_1detail_1_1buffers__iterator__types__helper_3_01false_01_4_1_1byte__type" ],
    [ "buffers_iterator_types_helper< true >", "structasio_1_1detail_1_1buffers__iterator__types__helper_3_01true_01_4.html", "structasio_1_1detail_1_1buffers__iterator__types__helper_3_01true_01_4" ],
    [ "byte_type", "structasio_1_1detail_1_1buffers__iterator__types__helper_3_01true_01_4_1_1byte__type.html", "structasio_1_1detail_1_1buffers__iterator__types__helper_3_01true_01_4_1_1byte__type" ],
    [ "buffers_iterator_types", "structasio_1_1detail_1_1buffers__iterator__types.html", "structasio_1_1detail_1_1buffers__iterator__types" ],
    [ "buffers_iterator", "classasio_1_1buffers__iterator.html", "classasio_1_1buffers__iterator" ],
    [ "buffers_begin", "buffers__iterator_8hpp.html#a9d6099d23e9bf78b2b1ad82d164d3d7e", null ],
    [ "buffers_end", "buffers__iterator_8hpp.html#a2ef4b181d4561848de38fac7907d4a0b", null ]
];
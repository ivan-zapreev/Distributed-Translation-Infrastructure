var classuva_1_1smt_1_1bpbd_1_1server_1_1trans__info__provider =
[
    [ "~trans_info_provider", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__info__provider.html#aedd04458be6a3e73af9099552c005921", null ],
    [ "get_trans_info", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__info__provider.html#a82092ac52f2db82d72d2d13e9b3b0620", null ]
];
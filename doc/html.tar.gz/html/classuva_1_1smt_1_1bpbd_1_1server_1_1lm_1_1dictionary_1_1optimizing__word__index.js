var classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1dictionary_1_1optimizing__word__index =
[
    [ "optimizing_word_index", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1dictionary_1_1optimizing__word__index.html#a0bf2e2ba600dd82b71cf5d12e6272cae", null ],
    [ "~optimizing_word_index", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1dictionary_1_1optimizing__word__index.html#a51f16a374a173acd644d9371b22cfcd5", null ],
    [ "count_word", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1dictionary_1_1optimizing__word__index.html#a7136ef021c82a24a98b8f334745701dc", null ],
    [ "do_post_actions", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1dictionary_1_1optimizing__word__index.html#ad0895972517a24928707dcf8cbef095e", null ],
    [ "do_post_word_count", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1dictionary_1_1optimizing__word__index.html#ab6f896a4de83ae4f4d15d1ffaabf65c7", null ],
    [ "get_number_of_words", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1dictionary_1_1optimizing__word__index.html#a683624c90e23d3d821ffa637a87a1d4c", null ],
    [ "get_word_id", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1dictionary_1_1optimizing__word__index.html#aafcc7f59a70769898cca5e283f340be1", null ],
    [ "is_post_actions_needed", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1dictionary_1_1optimizing__word__index.html#aacae85b7f0c4f5fc8a4835e994da6475", null ],
    [ "is_word_counts_needed", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1dictionary_1_1optimizing__word__index.html#ae4996023eca522ac632145dd58b411ed", null ],
    [ "is_word_registering_needed", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1dictionary_1_1optimizing__word__index.html#a0da36615a46a9f9112d376961c379e1c", null ],
    [ "register_word", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1dictionary_1_1optimizing__word__index.html#a03a89d044fb067a0d6a1eabbd81aaddb", null ],
    [ "reserve", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1dictionary_1_1optimizing__word__index.html#a38947d043d61a3f9a5acebf79c8e5f02", null ]
];
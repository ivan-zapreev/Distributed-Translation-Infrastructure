var classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1dictionary_1_1optimizing__word__index =
[
    [ "optimizing_word_index", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1dictionary_1_1optimizing__word__index.html#a0bf2e2ba600dd82b71cf5d12e6272cae", null ],
    [ "~optimizing_word_index", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1dictionary_1_1optimizing__word__index.html#a51f16a374a173acd644d9371b22cfcd5", null ],
    [ "count_word", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1dictionary_1_1optimizing__word__index.html#a7136ef021c82a24a98b8f334745701dc", null ],
    [ "do_post_actions", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1dictionary_1_1optimizing__word__index.html#ad0895972517a24928707dcf8cbef095e", null ],
    [ "do_post_word_count", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1dictionary_1_1optimizing__word__index.html#ab6f896a4de83ae4f4d15d1ffaabf65c7", null ],
    [ "get_number_of_words", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1dictionary_1_1optimizing__word__index.html#ac031050ec763d94b554dbf8105abf7c1", null ],
    [ "get_word_id", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1dictionary_1_1optimizing__word__index.html#a322456014702f69f68e57446e8b466af", null ],
    [ "is_post_actions_needed", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1dictionary_1_1optimizing__word__index.html#a0fd0b2eda7351e2df665840163c71db4", null ],
    [ "is_word_counts_needed", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1dictionary_1_1optimizing__word__index.html#a840eec0cdf2bc05f141c01ff2be5a3e9", null ],
    [ "is_word_registering_needed", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1dictionary_1_1optimizing__word__index.html#a44d269b5a1674ae045c472eeba062524", null ],
    [ "register_word", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1dictionary_1_1optimizing__word__index.html#a03a89d044fb067a0d6a1eabbd81aaddb", null ],
    [ "reserve", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1dictionary_1_1optimizing__word__index.html#a38947d043d61a3f9a5acebf79c8e5f02", null ]
];
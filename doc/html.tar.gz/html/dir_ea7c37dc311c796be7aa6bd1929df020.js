var dir_ea7c37dc311c796be7aa6bd1929df020 =
[
    [ "truecase", "dir_5a57b10c9ab5aa711d33dab95f0b565e.html", "dir_5a57b10c9ab5aa711d33dab95f0b565e" ],
    [ "lang_detect_nltk.py", "lang__detect__nltk_8py.html", "lang__detect__nltk_8py" ],
    [ "post_process_nltk.py", "post__process__nltk_8py.html", "post__process__nltk_8py" ],
    [ "pre_process_nltk.py", "pre__process__nltk_8py.html", "pre__process__nltk_8py" ],
    [ "pre_process_snlp.py", "pre__process__snlp_8py.html", "pre__process__snlp_8py" ]
];
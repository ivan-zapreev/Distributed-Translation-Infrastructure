var classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1caching_1_1_bitmap_hash_cache =
[
    [ "BitmapHashCache", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1caching_1_1_bitmap_hash_cache.html#a17b25628aeb35ab8e652e4d122e7207e", null ],
    [ "~BitmapHashCache", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1caching_1_1_bitmap_hash_cache.html#ad49f58d1a8c1eb42f8d087dc3113ceb6", null ],
    [ "cache_m_gram_hash", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1caching_1_1_bitmap_hash_cache.html#a26c8629c18ae22880573e68d1b27ba3e", null ],
    [ "is_hash_cached", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1caching_1_1_bitmap_hash_cache.html#af7668c2ab9812617309316a788f29466", null ],
    [ "pre_allocate", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1caching_1_1_bitmap_hash_cache.html#a6855f0989c36321f0a6faed788adfe20", null ]
];
var websocket__client_8hpp =
[
    [ "websocket_client", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1websocket_1_1websocket__client.html", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1websocket_1_1websocket__client" ],
    [ "ASIO_STANDALONE", "websocket__client_8hpp.html#a5b90f4adb6bc09ca319c35c3448ee67a", null ],
    [ "IS_TLS_SUPPORT", "websocket__client_8hpp.html#ae69660db74f300dbd24d5e979df18b43", null ]
];
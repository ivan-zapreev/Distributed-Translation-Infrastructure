var classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1proxy_1_1lm__proxy =
[
    [ "~lm_proxy", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1proxy_1_1lm__proxy.html#a35c362a07c2346644db0733367cc9a3e", null ],
    [ "allocate_fast_query_proxy", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1proxy_1_1lm__proxy.html#a4562156dc6054b7cfb0a30119084a3ff", null ],
    [ "allocate_slow_query_proxy", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1proxy_1_1lm__proxy.html#aeda3274528221eeacd4d25d6355a4edb", null ],
    [ "connect", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1proxy_1_1lm__proxy.html#a58ab183548efaa2fc5aa7081a7a5d174", null ],
    [ "disconnect", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1proxy_1_1lm__proxy.html#a0fd72b2586f75737dfa71e06d3a6c464", null ],
    [ "dispose_fast_query_proxy", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1proxy_1_1lm__proxy.html#ac9a6a51b9ca20e61f8297e85e470e4af", null ],
    [ "dispose_slow_query_proxy", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1proxy_1_1lm__proxy.html#a6b1f23d2007cf4c44e812ac037ac8fe8", null ]
];
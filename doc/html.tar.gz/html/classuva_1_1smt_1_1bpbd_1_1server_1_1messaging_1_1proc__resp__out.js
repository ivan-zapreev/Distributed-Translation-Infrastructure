var classuva_1_1smt_1_1bpbd_1_1server_1_1messaging_1_1proc__resp__out =
[
    [ "set_chunk", "classuva_1_1smt_1_1bpbd_1_1server_1_1messaging_1_1proc__resp__out.html#a7c7889c8b23889db3ce304a846ea45e9", null ],
    [ "set_job_token", "classuva_1_1smt_1_1bpbd_1_1server_1_1messaging_1_1proc__resp__out.html#aa6f0e69e11a46ee706030af989f9a05b", null ],
    [ "set_language", "classuva_1_1smt_1_1bpbd_1_1server_1_1messaging_1_1proc__resp__out.html#a2f3d19d9d7c0792fdf01d9a80196dc19", null ],
    [ "set_status", "classuva_1_1smt_1_1bpbd_1_1server_1_1messaging_1_1proc__resp__out.html#ab07aac1eddd84a74188743cad7fe4a1d", null ]
];
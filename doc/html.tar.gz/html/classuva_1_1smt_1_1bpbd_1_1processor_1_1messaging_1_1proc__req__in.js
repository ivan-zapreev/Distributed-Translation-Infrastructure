var classuva_1_1smt_1_1bpbd_1_1processor_1_1messaging_1_1proc__req__in =
[
    [ "proc_req_in", "classuva_1_1smt_1_1bpbd_1_1processor_1_1messaging_1_1proc__req__in.html#a57177c08bbfeb762d1fac144635575d2", null ],
    [ "~proc_req_in", "classuva_1_1smt_1_1bpbd_1_1processor_1_1messaging_1_1proc__req__in.html#a50d605e46d26adf0cd6a876e8e43b9d4", null ],
    [ "get_chunk", "classuva_1_1smt_1_1bpbd_1_1processor_1_1messaging_1_1proc__req__in.html#a15d8275b4d206dee6d91229a919ff534", null ],
    [ "get_chunk_idx", "classuva_1_1smt_1_1bpbd_1_1processor_1_1messaging_1_1proc__req__in.html#aa8439936c2866cc28b27f404aa7ecd3b", null ],
    [ "get_job_token", "classuva_1_1smt_1_1bpbd_1_1processor_1_1messaging_1_1proc__req__in.html#a06236728a40b886b03894ec74cf70fb8", null ],
    [ "get_language", "classuva_1_1smt_1_1bpbd_1_1processor_1_1messaging_1_1proc__req__in.html#a63dd95c9e0623f1f008be9ff88423bae", null ],
    [ "get_num_chunks", "classuva_1_1smt_1_1bpbd_1_1processor_1_1messaging_1_1proc__req__in.html#a8be35178617428c41390d54852c33f7b", null ],
    [ "m_inc_msg", "classuva_1_1smt_1_1bpbd_1_1processor_1_1messaging_1_1proc__req__in.html#a862a7de23a9398b9350b6ad05bb6661b", null ]
];
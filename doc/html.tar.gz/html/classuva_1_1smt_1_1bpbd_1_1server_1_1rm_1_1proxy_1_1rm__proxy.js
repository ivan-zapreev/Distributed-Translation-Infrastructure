var classuva_1_1smt_1_1bpbd_1_1server_1_1rm_1_1proxy_1_1rm__proxy =
[
    [ "~rm_proxy", "classuva_1_1smt_1_1bpbd_1_1server_1_1rm_1_1proxy_1_1rm__proxy.html#a6faff7aa895e532873a8886fbb3b9808", null ],
    [ "allocate_query_proxy", "classuva_1_1smt_1_1bpbd_1_1server_1_1rm_1_1proxy_1_1rm__proxy.html#adf3e19602a0092ecd3da07823db7961c", null ],
    [ "connect", "classuva_1_1smt_1_1bpbd_1_1server_1_1rm_1_1proxy_1_1rm__proxy.html#acbc4f1b6ee8eb90ac1f12683982ecdfb", null ],
    [ "disconnect", "classuva_1_1smt_1_1bpbd_1_1server_1_1rm_1_1proxy_1_1rm__proxy.html#a121767bcb9a3b1672b2a7c7b37302037", null ],
    [ "dispose_query_proxy", "classuva_1_1smt_1_1bpbd_1_1server_1_1rm_1_1proxy_1_1rm__proxy.html#a4f9ad9537cd74044b8f003bc464e1adf", null ]
];
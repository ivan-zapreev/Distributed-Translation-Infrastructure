var classuva_1_1smt_1_1bpbd_1_1client_1_1translation__client =
[
    [ "client", "classuva_1_1smt_1_1bpbd_1_1client_1_1translation__client.html#a390fa2321ff9549e1f31ca2dcbd4a88c", null ],
    [ "conn_close_notifier", "classuva_1_1smt_1_1bpbd_1_1client_1_1translation__client.html#a6bb76738c95be98f5d13370d8e6a1176", null ],
    [ "response_setter", "classuva_1_1smt_1_1bpbd_1_1client_1_1translation__client.html#aee49acfd2764e30f042c29b1d365f21d", null ],
    [ "translation_client", "classuva_1_1smt_1_1bpbd_1_1client_1_1translation__client.html#ae892d7cccc21df88b04e9d26c4f8c23c", null ],
    [ "~translation_client", "classuva_1_1smt_1_1bpbd_1_1client_1_1translation__client.html#ad3e2c66b9740dafbcbb1dd2be2cc8116", null ],
    [ "connect", "classuva_1_1smt_1_1bpbd_1_1client_1_1translation__client.html#a84545fb376d8deb41ce74b552ca5d9a0", null ],
    [ "disconnect", "classuva_1_1smt_1_1bpbd_1_1client_1_1translation__client.html#a3112325b486803b3e788b6f3ff3ad755", null ],
    [ "get_uri", "classuva_1_1smt_1_1bpbd_1_1client_1_1translation__client.html#a3eda42ede736d896f012aabefaabad69", null ],
    [ "on_close", "classuva_1_1smt_1_1bpbd_1_1client_1_1translation__client.html#ad37d08d88eff9a5eadf5ce26dc01b80a", null ],
    [ "on_fail", "classuva_1_1smt_1_1bpbd_1_1client_1_1translation__client.html#a749abfbb48da4b4afeb9059f8444bbba", null ],
    [ "on_message", "classuva_1_1smt_1_1bpbd_1_1client_1_1translation__client.html#a2249d6ab4f4dd15a37703d7796a60c48", null ],
    [ "on_open", "classuva_1_1smt_1_1bpbd_1_1client_1_1translation__client.html#a1103c5f24564a2d96484c1cd0042946e", null ],
    [ "send", "classuva_1_1smt_1_1bpbd_1_1client_1_1translation__client.html#a38bf3e2d812a0d7fe12a3f3f5f6af7e3", null ],
    [ "wait_connect", "classuva_1_1smt_1_1bpbd_1_1client_1_1translation__client.html#aedce4e9a9aae9858530f230d56c2733c", null ]
];
var classuva_1_1smt_1_1bpbd_1_1client_1_1translation__client =
[
    [ "client", "classuva_1_1smt_1_1bpbd_1_1client_1_1translation__client.html#a390fa2321ff9549e1f31ca2dcbd4a88c", null ],
    [ "conn_status_notifier", "classuva_1_1smt_1_1bpbd_1_1client_1_1translation__client.html#a9596c05658488292fd71b524d2cf1899", null ],
    [ "server_message_setter", "classuva_1_1smt_1_1bpbd_1_1client_1_1translation__client.html#a4cb031044d601e534789fa8112096b18", null ],
    [ "translation_client", "classuva_1_1smt_1_1bpbd_1_1client_1_1translation__client.html#abf63229469240bfafbfe2ad2382966b7", null ],
    [ "~translation_client", "classuva_1_1smt_1_1bpbd_1_1client_1_1translation__client.html#ad3e2c66b9740dafbcbb1dd2be2cc8116", null ],
    [ "connect", "classuva_1_1smt_1_1bpbd_1_1client_1_1translation__client.html#a84545fb376d8deb41ce74b552ca5d9a0", null ],
    [ "connect_nb", "classuva_1_1smt_1_1bpbd_1_1client_1_1translation__client.html#a00d2f95dd4eb957cdd6c883bd00de0ae", null ],
    [ "disconnect", "classuva_1_1smt_1_1bpbd_1_1client_1_1translation__client.html#a3112325b486803b3e788b6f3ff3ad755", null ],
    [ "get_uri", "classuva_1_1smt_1_1bpbd_1_1client_1_1translation__client.html#a10c605d7917fe4f0215a39c7dbde249c", null ],
    [ "handle_closed_connection", "classuva_1_1smt_1_1bpbd_1_1client_1_1translation__client.html#a29c3d797471ce388012643d1e91584d2", null ],
    [ "is_connected", "classuva_1_1smt_1_1bpbd_1_1client_1_1translation__client.html#adc9dda7b0a101d66b9b037e7104a4675", null ],
    [ "on_close", "classuva_1_1smt_1_1bpbd_1_1client_1_1translation__client.html#ad37d08d88eff9a5eadf5ce26dc01b80a", null ],
    [ "on_fail", "classuva_1_1smt_1_1bpbd_1_1client_1_1translation__client.html#a749abfbb48da4b4afeb9059f8444bbba", null ],
    [ "on_message", "classuva_1_1smt_1_1bpbd_1_1client_1_1translation__client.html#a2249d6ab4f4dd15a37703d7796a60c48", null ],
    [ "on_open", "classuva_1_1smt_1_1bpbd_1_1client_1_1translation__client.html#a1103c5f24564a2d96484c1cd0042946e", null ],
    [ "send", "classuva_1_1smt_1_1bpbd_1_1client_1_1translation__client.html#aa96ff390c4588b42b45128cbbe13eb2b", null ],
    [ "wait_connect", "classuva_1_1smt_1_1bpbd_1_1client_1_1translation__client.html#aedce4e9a9aae9858530f230d56c2733c", null ]
];
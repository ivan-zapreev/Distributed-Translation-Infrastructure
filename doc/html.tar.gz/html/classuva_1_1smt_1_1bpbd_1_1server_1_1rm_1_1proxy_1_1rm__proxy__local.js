var classuva_1_1smt_1_1bpbd_1_1server_1_1rm_1_1proxy_1_1rm__proxy__local =
[
    [ "rm_proxy_local", "classuva_1_1smt_1_1bpbd_1_1server_1_1rm_1_1proxy_1_1rm__proxy__local.html#a334f263b374281ce703231302212617a", null ],
    [ "~rm_proxy_local", "classuva_1_1smt_1_1bpbd_1_1server_1_1rm_1_1proxy_1_1rm__proxy__local.html#a6fd8b6d8147f51c847fee206b80b237c", null ],
    [ "allocate_query_proxy", "classuva_1_1smt_1_1bpbd_1_1server_1_1rm_1_1proxy_1_1rm__proxy__local.html#a697c5402937d2f3f55500ed1c2074fc7", null ],
    [ "connect", "classuva_1_1smt_1_1bpbd_1_1server_1_1rm_1_1proxy_1_1rm__proxy__local.html#a7a92980f74178062d198640cd55ed57c", null ],
    [ "disconnect", "classuva_1_1smt_1_1bpbd_1_1server_1_1rm_1_1proxy_1_1rm__proxy__local.html#a43f0158c8eba7c695b57a6c9245b61fc", null ],
    [ "dispose_query_proxy", "classuva_1_1smt_1_1bpbd_1_1server_1_1rm_1_1proxy_1_1rm__proxy__local.html#a3a26102b7b9b3ecc4d1a8627751406a6", null ],
    [ "load_model_data", "classuva_1_1smt_1_1bpbd_1_1server_1_1rm_1_1proxy_1_1rm__proxy__local.html#a29f305210313916e132a2ecee15891d4", null ]
];
var dir_170c035642c4888cf595e89e8bac84f9 =
[
    [ "base.hpp", "processors_2base_8hpp.html", "processors_2base_8hpp" ],
    [ "hybi00.hpp", "hybi00_8hpp.html", [
      [ "hybi00", "classwebsocketpp_1_1processor_1_1hybi00.html", "classwebsocketpp_1_1processor_1_1hybi00" ]
    ] ],
    [ "hybi07.hpp", "hybi07_8hpp.html", [
      [ "hybi07", "classwebsocketpp_1_1processor_1_1hybi07.html", "classwebsocketpp_1_1processor_1_1hybi07" ]
    ] ],
    [ "hybi08.hpp", "hybi08_8hpp.html", [
      [ "hybi08", "classwebsocketpp_1_1processor_1_1hybi08.html", "classwebsocketpp_1_1processor_1_1hybi08" ]
    ] ],
    [ "hybi13.hpp", "hybi13_8hpp.html", [
      [ "hybi13", "classwebsocketpp_1_1processor_1_1hybi13.html", "classwebsocketpp_1_1processor_1_1hybi13" ],
      [ "msg_metadata", "structwebsocketpp_1_1processor_1_1hybi13_1_1msg__metadata.html", "structwebsocketpp_1_1processor_1_1hybi13_1_1msg__metadata" ]
    ] ],
    [ "processor.hpp", "processor_8hpp.html", "processor_8hpp" ]
];
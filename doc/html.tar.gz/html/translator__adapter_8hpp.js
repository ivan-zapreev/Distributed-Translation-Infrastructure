var translator__adapter_8hpp =
[
    [ "translator_adapter", "classuva_1_1smt_1_1bpbd_1_1balancer_1_1translator__adapter.html", "classuva_1_1smt_1_1bpbd_1_1balancer_1_1translator__adapter" ],
    [ "adapter_disc_notifier", "translator__adapter_8hpp.html#a169a282929e608d24256fbb06a0c9c53", null ],
    [ "closed_conn_notifier_type", "translator__adapter_8hpp.html#a56b4621d1204c4a9715814f52c746832", null ],
    [ "ready_conn_notifier_type", "translator__adapter_8hpp.html#a07603f39d1d76924994365f0cf95f20c", null ],
    [ "trans_resp_notifier", "translator__adapter_8hpp.html#af6bc1015b291b28e817c6eec49f32943", null ]
];
var classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1builders_1_1tm__basic__builder =
[
    [ "tm_basic_builder", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1builders_1_1tm__basic__builder.html#a3acde5a466b7d9e97e4cf7ffdc72dd87", null ],
    [ "~tm_basic_builder", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1builders_1_1tm__basic__builder.html#aaf4afc4e2bbb2a675a64603ceecdc8e9", null ],
    [ "add_unk_translation", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1builders_1_1tm__basic__builder.html#a3990eaf128683fa52c8a43a1498bbf6c", null ],
    [ "build", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1builders_1_1tm__basic__builder.html#a07847280269c80b4e7d622da3e654c8e", null ],
    [ "count_source_phrases", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1builders_1_1tm__basic__builder.html#a3a746c653bfdbc8d5e8ad1b8393ba578", null ],
    [ "is_good_features", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1builders_1_1tm__basic__builder.html#af197ee4bc0a4b182cf3823cd6b4a127d", null ],
    [ "parse_tm_file", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1builders_1_1tm__basic__builder.html#ae343a8c5d672c4c530f11eee3c19d3ee", null ],
    [ "post_process_feature", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1builders_1_1tm__basic__builder.html#a55ed944c97e2e9896b6ada55899b9828", null ],
    [ "process_features", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1builders_1_1tm__basic__builder.html#ab0c3a3a7c88c9ebf39007bd0c8f213ad", null ],
    [ "process_source_entries", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1builders_1_1tm__basic__builder.html#ab815d0b80278bea0ab5fdc9a527fa6f2", null ],
    [ "process_target_entry", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1builders_1_1tm__basic__builder.html#aa4176dc8b7c74aebf387f6bd6d80ec72", null ]
];
var classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1builders_1_1tm__basic__builder =
[
    [ "tm_basic_builder", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1builders_1_1tm__basic__builder.html#a3acde5a466b7d9e97e4cf7ffdc72dd87", null ],
    [ "~tm_basic_builder", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1builders_1_1tm__basic__builder.html#aaf4afc4e2bbb2a675a64603ceecdc8e9", null ],
    [ "add_unk_translation", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1builders_1_1tm__basic__builder.html#a3990eaf128683fa52c8a43a1498bbf6c", null ],
    [ "build", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1builders_1_1tm__basic__builder.html#a07847280269c80b4e7d622da3e654c8e", null ],
    [ "count_source_phrases", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1builders_1_1tm__basic__builder.html#a3a746c653bfdbc8d5e8ad1b8393ba578", null ],
    [ "is_good_features", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1builders_1_1tm__basic__builder.html#aac2e53b1418a4ba6b381fd0ad9cfb704", null ],
    [ "parse_tm_file", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1builders_1_1tm__basic__builder.html#ae343a8c5d672c4c530f11eee3c19d3ee", null ],
    [ "post_process_feature", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1builders_1_1tm__basic__builder.html#a822a050e3d63a32be5931eb0887d457b", null ],
    [ "process_features", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1builders_1_1tm__basic__builder.html#aa88428ebf851d58d367c2b52b62c55f9", null ],
    [ "process_source_entries", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1builders_1_1tm__basic__builder.html#ab815d0b80278bea0ab5fdc9a527fa6f2", null ],
    [ "process_target_entry", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1builders_1_1tm__basic__builder.html#aacdb1ea0ff9474ecc0d089c2ad52f10e", null ]
];
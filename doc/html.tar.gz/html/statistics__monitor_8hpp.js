var statistics__monitor_8hpp =
[
    [ "memory_usage", "structuva_1_1utils_1_1monitor_1_1memory__usage.html", "structuva_1_1utils_1_1monitor_1_1memory__usage" ],
    [ "stat_monitor", "classuva_1_1utils_1_1monitor_1_1stat__monitor.html", null ],
    [ "DECLARE_MONITOR_STATS", "statistics__monitor_8hpp.html#a402ee36b655a140011f9fd7b43cec024", null ],
    [ "INITIALIZE_STATS", "statistics__monitor_8hpp.html#ac70ee885b74e5b90500e40ecf17fc0a6", null ],
    [ "REPORT_STATS", "statistics__monitor_8hpp.html#a223ff61ea0f6ed9a955bf69fbab3472f", null ],
    [ "TMemotyUsage", "statistics__monitor_8hpp.html#a49c196b840bf3fd2dc8cab233952922a", null ],
    [ "BYTES_ONE_MB", "statistics__monitor_8hpp.html#aae853f690eea0d25fcf5e288859a3c75", null ]
];
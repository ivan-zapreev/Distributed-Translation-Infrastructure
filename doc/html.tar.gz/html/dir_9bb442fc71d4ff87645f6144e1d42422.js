var dir_9bb442fc71d4ff87645f6144e1d42422 =
[
    [ "tm_proxy.hpp", "tm__proxy_8hpp.html", [
      [ "tm_proxy", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1proxy_1_1tm__proxy.html", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1proxy_1_1tm__proxy" ]
    ] ],
    [ "tm_proxy_local.hpp", "tm__proxy__local_8hpp.html", [
      [ "tm_proxy_local", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1proxy_1_1tm__proxy__local.html", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1proxy_1_1tm__proxy__local" ]
    ] ],
    [ "tm_query_proxy.hpp", "tm__query__proxy_8hpp.html", [
      [ "tm_query_proxy", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1proxy_1_1tm__query__proxy.html", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1proxy_1_1tm__query__proxy" ]
    ] ],
    [ "tm_query_proxy_local.hpp", "tm__query__proxy__local_8hpp.html", [
      [ "tm_query_proxy_local", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1proxy_1_1tm__query__proxy__local.html", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1proxy_1_1tm__query__proxy__local" ]
    ] ]
];
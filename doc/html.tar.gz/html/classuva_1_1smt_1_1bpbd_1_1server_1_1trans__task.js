var classuva_1_1smt_1_1bpbd_1_1server_1_1trans__task =
[
    [ "cancel_task_notifier", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__task.html#aa3ee37277c0d0fd6ffdb44b67f1a5384", null ],
    [ "done_task_notifier", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__task.html#a0bbeddd9f0896c3ecb32ed4c2c5e66e1", null ],
    [ "trans_task", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__task.html#a0fa8eacb72332e4a4e2ee8f76b286dfd", null ],
    [ "~trans_task", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__task.html#aa1bb5790e96aa17e38dc8b5ece08e961", null ],
    [ "cancel", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__task.html#afb1b79f1939721f90458ae41e6775325", null ],
    [ "get_code", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__task.html#a7989069b2c8ac4a53c4b61cfb7ca2ae9", null ],
    [ "get_source_text", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__task.html#a6207deffc6fece01ae5fe55f14da31f9", null ],
    [ "get_target_text", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__task.html#a6b6e12de683ef6ec75ae3d2ef53c4845", null ],
    [ "get_task_id", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__task.html#a7c4fb56a5ad154a01e0b1ce3224029ae", null ],
    [ "process_task_result", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__task.html#a73c3298cc2d8ab7eaadc7d3e08e444bd", null ],
    [ "set_cancel_task_notifier", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__task.html#ad1a21a8c197d2fe7d23963ab0fda85b4", null ],
    [ "translate", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__task.html#adfc46fc066c24a06a0e455e640c36904", null ]
];
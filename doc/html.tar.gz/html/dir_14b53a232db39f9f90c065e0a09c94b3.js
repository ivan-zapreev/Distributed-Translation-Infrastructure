var dir_14b53a232db39f9f90c065e0a09c94b3 =
[
    [ "sentence_data_map.hpp", "sentence__data__map_8hpp.html", "sentence__data__map_8hpp" ],
    [ "sentence_decoder.hpp", "sentence__decoder_8hpp.html", [
      [ "sentence_decoder", "classuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1sentence_1_1sentence__decoder.html", "classuva_1_1smt_1_1bpbd_1_1server_1_1decoder_1_1sentence_1_1sentence__decoder" ]
    ] ]
];
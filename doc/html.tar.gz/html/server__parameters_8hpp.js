var server__parameters_8hpp =
[
    [ "server_parameters_struct", "structuva_1_1smt_1_1bpbd_1_1server_1_1server__parameters__struct.html", "structuva_1_1smt_1_1bpbd_1_1server_1_1server__parameters__struct" ],
    [ "server_parameters", "server__parameters_8hpp.html#a1d52357b5a532ed378439edfa8be8969", null ]
];
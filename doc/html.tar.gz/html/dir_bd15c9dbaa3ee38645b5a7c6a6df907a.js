var dir_bd15c9dbaa3ee38645b5a7c6a6df907a =
[
    [ "client_config.hpp", "client__config_8hpp.html", [
      [ "client_config", "structuva_1_1smt_1_1bpbd_1_1client_1_1client__config.html", "structuva_1_1smt_1_1bpbd_1_1client_1_1client__config" ]
    ] ],
    [ "trans_job.hpp", "client_2trans__job_8hpp.html", "client_2trans__job_8hpp" ],
    [ "trans_job_status.hpp", "trans__job__status_8hpp.html", "trans__job__status_8hpp" ],
    [ "trans_manager.hpp", "client_2trans__manager_8hpp.html", [
      [ "trans_manager", "classuva_1_1smt_1_1bpbd_1_1client_1_1trans__manager.html", "classuva_1_1smt_1_1bpbd_1_1client_1_1trans__manager" ]
    ] ],
    [ "translation_client.hpp", "translation__client_8hpp.html", "translation__client_8hpp" ]
];
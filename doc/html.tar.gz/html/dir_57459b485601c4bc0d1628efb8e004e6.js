var dir_57459b485601c4bc0d1628efb8e004e6 =
[
    [ "task_pool.hpp", "task__pool_8hpp.html", [
      [ "task_pool", "classuva_1_1utils_1_1threads_1_1task__pool.html", "classuva_1_1utils_1_1threads_1_1task__pool" ]
    ] ],
    [ "task_pool_worker.hpp", "task__pool__worker_8hpp.html", [
      [ "task_pool", "classuva_1_1utils_1_1threads_1_1task__pool.html", "classuva_1_1utils_1_1threads_1_1task__pool" ],
      [ "task_pool_worker", "classuva_1_1utils_1_1threads_1_1task__pool__worker.html", "classuva_1_1utils_1_1threads_1_1task__pool__worker" ]
    ] ],
    [ "threads.hpp", "threads_8hpp.html", "threads_8hpp" ]
];
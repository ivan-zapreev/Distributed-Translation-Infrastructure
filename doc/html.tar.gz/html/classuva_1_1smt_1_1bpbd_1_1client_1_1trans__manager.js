var classuva_1_1smt_1_1bpbd_1_1client_1_1trans__manager =
[
    [ "jobs_list_iter_type", "classuva_1_1smt_1_1bpbd_1_1client_1_1trans__manager.html#a07f34153efcba519e36ead6bf39c881e", null ],
    [ "jobs_list_type", "classuva_1_1smt_1_1bpbd_1_1client_1_1trans__manager.html#aab9c124d930eca091e5140faa0b306f2", null ],
    [ "jobs_map_iter_type", "classuva_1_1smt_1_1bpbd_1_1client_1_1trans__manager.html#a682b34240d22a905295f1273cfd03310", null ],
    [ "jobs_map_type", "classuva_1_1smt_1_1bpbd_1_1client_1_1trans__manager.html#a8aac327989f3657f3977a52e614262ef", null ],
    [ "trans_manager", "classuva_1_1smt_1_1bpbd_1_1client_1_1trans__manager.html#a5eef60a216b435f787253352810b1cda", null ],
    [ "~trans_manager", "classuva_1_1smt_1_1bpbd_1_1client_1_1trans__manager.html#a2a719a7a4de3935f6c4caa4cf2b98aa5", null ],
    [ "check_jobs_done_and_notify", "classuva_1_1smt_1_1bpbd_1_1client_1_1trans__manager.html#ad36b90b1a5f36a6a4ae92460aa242f2a", null ],
    [ "get_num_of_sentences", "classuva_1_1smt_1_1bpbd_1_1client_1_1trans__manager.html#af6f6b2fabe28846158ba8b53fc9d07d9", null ],
    [ "notify_conn_closed", "classuva_1_1smt_1_1bpbd_1_1client_1_1trans__manager.html#ac69d151183cd28dae1ac0ca96664dda9", null ],
    [ "notify_jobs_done", "classuva_1_1smt_1_1bpbd_1_1client_1_1trans__manager.html#a6c8d85fe4ba5cd8bcb5e067f9754b1be", null ],
    [ "notify_jobs_sent", "classuva_1_1smt_1_1bpbd_1_1client_1_1trans__manager.html#a7827236377e8690c42d96a0f8f2bb138", null ],
    [ "send_translation_jobs", "classuva_1_1smt_1_1bpbd_1_1client_1_1trans__manager.html#a3cf856ae3a65d513e7d8e0759b969517", null ],
    [ "set_job_response", "classuva_1_1smt_1_1bpbd_1_1client_1_1trans__manager.html#a6e9a3d57534485af5308c84f4dc634cf", null ],
    [ "set_server_message", "classuva_1_1smt_1_1bpbd_1_1client_1_1trans__manager.html#a7518a15b2aa7dcafdc3fe48707ced2bc", null ],
    [ "start", "classuva_1_1smt_1_1bpbd_1_1client_1_1trans__manager.html#a45766408524b5edef15a947786a1bd5b", null ],
    [ "stop", "classuva_1_1smt_1_1bpbd_1_1client_1_1trans__manager.html#a9ef6ac7259d1e31b4dc9df96d557ec34", null ],
    [ "store_targety_data", "classuva_1_1smt_1_1bpbd_1_1client_1_1trans__manager.html#ab993a3db0a7bc51298b393facbc6b332", null ],
    [ "wait", "classuva_1_1smt_1_1bpbd_1_1client_1_1trans__manager.html#afac6e2a3b5977f7df497067b1a623f4d", null ],
    [ "write_received_job_result", "classuva_1_1smt_1_1bpbd_1_1client_1_1trans__manager.html#af1b118e23c92d88eeab7b6d61a9ef686", null ],
    [ "write_result_to_file", "classuva_1_1smt_1_1bpbd_1_1client_1_1trans__manager.html#a78c14976fac089d29a423e597a4af98f", null ]
];
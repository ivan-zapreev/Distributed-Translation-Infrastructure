var classuva_1_1smt_1_1bpbd_1_1client_1_1trans__manager =
[
    [ "jobs_list_type", "classuva_1_1smt_1_1bpbd_1_1client_1_1trans__manager.html#aab9c124d930eca091e5140faa0b306f2", null ],
    [ "jobs_map_type", "classuva_1_1smt_1_1bpbd_1_1client_1_1trans__manager.html#a8aac327989f3657f3977a52e614262ef", null ],
    [ "trans_manager", "classuva_1_1smt_1_1bpbd_1_1client_1_1trans__manager.html#aee6e85503f2f15e08e30d42f23da5524", null ],
    [ "~trans_manager", "classuva_1_1smt_1_1bpbd_1_1client_1_1trans__manager.html#a2a719a7a4de3935f6c4caa4cf2b98aa5", null ],
    [ "get_act_num_req", "classuva_1_1smt_1_1bpbd_1_1client_1_1trans__manager.html#ab91acfc5d59949130c6f97bb364f7b0d", null ],
    [ "get_exp_num_resp", "classuva_1_1smt_1_1bpbd_1_1client_1_1trans__manager.html#af8231cfed5c7cb70293151c57cbe7857", null ],
    [ "process_results", "classuva_1_1smt_1_1bpbd_1_1client_1_1trans__manager.html#a003903a9e8850d2f62d3dd3d62d049b5", null ],
    [ "send_job_requests", "classuva_1_1smt_1_1bpbd_1_1client_1_1trans__manager.html#af5214185c249f693fc7f49927b28fc21", null ],
    [ "set_job_response", "classuva_1_1smt_1_1bpbd_1_1client_1_1trans__manager.html#a1a804cf16116f3f312c215870ae75988", null ],
    [ "start", "classuva_1_1smt_1_1bpbd_1_1client_1_1trans__manager.html#a45766408524b5edef15a947786a1bd5b", null ]
];
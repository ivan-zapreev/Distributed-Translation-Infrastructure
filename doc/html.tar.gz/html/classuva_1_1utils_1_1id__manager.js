var classuva_1_1utils_1_1id__manager =
[
    [ "id_manager", "classuva_1_1utils_1_1id__manager.html#ab91ce9bedb1afedc7e18d715b46b3883", null ],
    [ "get_min_id", "classuva_1_1utils_1_1id__manager.html#a7efc11b187639d067d42953be9ec2b78", null ],
    [ "get_next_id", "classuva_1_1utils_1_1id__manager.html#aaca83e2262a396cbcd27c75bb71e2259", null ]
];
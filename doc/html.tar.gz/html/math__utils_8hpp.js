var math__utils_8hpp =
[
    [ "BYTE_IDX", "math__utils_8hpp.html#a7f0f0aa2d8a46fb70b89e38da72abd37", null ],
    [ "BYTES_TO_BITS", "math__utils_8hpp.html#a1178e1e3118ed30f4ed917b18b1e0961", null ],
    [ "HANDLE_ENDIAN", "math__utils_8hpp.html#a87e2623ee539f873f35cc3896dcc6860", null ],
    [ "NUM_BITS_REMAINDER", "math__utils_8hpp.html#a6a5e22024bb4e970642e00befa8727b9", null ],
    [ "NUM_BYTES_4_BITS", "math__utils_8hpp.html#aa8795dc3825e3a5e2381c593f1d14f5e", null ],
    [ "NUM_FULL_BYTES", "math__utils_8hpp.html#a1ee34e6ad19b67551cfa85f3d3e2d88e", null ],
    [ "REMAINING_BIT_IDX", "math__utils_8hpp.html#a20af5a9dc33935882c0d7f2c64e23556", null ],
    [ "VALUE_LEN_BYTES", "math__utils_8hpp.html#abb235d96b5acfb3cf6ee016f8c3befc7", null ],
    [ "ceil", "math__utils_8hpp.html#a1c7fa08dcebb20ed8f0d12ec5cfa513d", null ],
    [ "log2", "math__utils_8hpp.html#a51d8e9d286b0ac9c0d01350081008082", null ],
    [ "power", "math__utils_8hpp.html#af88edac03f2feda3027da86d576d5b46", null ]
];
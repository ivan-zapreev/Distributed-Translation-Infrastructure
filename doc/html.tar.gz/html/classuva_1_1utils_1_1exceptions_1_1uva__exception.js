var classuva_1_1utils_1_1exceptions_1_1uva__exception =
[
    [ "uva_exception", "classuva_1_1utils_1_1exceptions_1_1uva__exception.html#a03defbe6035043210bcc5376880c0e21", null ],
    [ "uva_exception", "classuva_1_1utils_1_1exceptions_1_1uva__exception.html#a4309971ffce6c372a55e6fb9dd30886a", null ],
    [ "uva_exception", "classuva_1_1utils_1_1exceptions_1_1uva__exception.html#ad161d76a5a99fe45c79c72c4dbcdae49", null ],
    [ "~uva_exception", "classuva_1_1utils_1_1exceptions_1_1uva__exception.html#ac79ca9e8ccfce51e17f34381ebd45ffd", null ],
    [ "get_message", "classuva_1_1utils_1_1exceptions_1_1uva__exception.html#a3a7edd62a730e13484694fc9d7d1c4ed", null ],
    [ "what", "classuva_1_1utils_1_1exceptions_1_1uva__exception.html#a40f5f6bee8b06d8e6eb7c0cec27e65b1", null ]
];
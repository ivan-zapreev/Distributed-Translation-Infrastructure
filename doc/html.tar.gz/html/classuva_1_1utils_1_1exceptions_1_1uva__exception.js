var classuva_1_1utils_1_1exceptions_1_1uva__exception =
[
    [ "uva_exception", "classuva_1_1utils_1_1exceptions_1_1uva__exception.html#a03defbe6035043210bcc5376880c0e21", null ],
    [ "uva_exception", "classuva_1_1utils_1_1exceptions_1_1uva__exception.html#a4309971ffce6c372a55e6fb9dd30886a", null ],
    [ "uva_exception", "classuva_1_1utils_1_1exceptions_1_1uva__exception.html#ad161d76a5a99fe45c79c72c4dbcdae49", null ],
    [ "~uva_exception", "classuva_1_1utils_1_1exceptions_1_1uva__exception.html#ac79ca9e8ccfce51e17f34381ebd45ffd", null ],
    [ "what", "classuva_1_1utils_1_1exceptions_1_1uva__exception.html#a41db65719eb16a2e1a5da3ee20987ebb", null ],
    [ "what_str", "classuva_1_1utils_1_1exceptions_1_1uva__exception.html#af31f2ef9acb3aa9beb2c075cac5065dc", null ]
];
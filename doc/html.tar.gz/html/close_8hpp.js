var close_8hpp =
[
    [ "code_converter", "unionwebsocketpp_1_1close_1_1code__converter.html", "unionwebsocketpp_1_1close_1_1code__converter" ],
    [ "value", "close_8hpp.html#a8614a5c4733d708e2d2a32191c5bef84", null ],
    [ "extract_code", "close_8hpp.html#aa47dacf7d2e13705d1f68d9ab5b9dad0", null ],
    [ "extract_reason", "close_8hpp.html#a537f66833c7b6e745b3cf5dc0252c0ca", null ],
    [ "get_string", "close_8hpp.html#a4bf4987c79165b134ed1207a567ce209", null ],
    [ "invalid", "close_8hpp.html#ad024f852889be28eadcec8209fdf9bc8", null ],
    [ "reserved", "close_8hpp.html#af26a61f8a8c3247cf656349f96ea3008", null ],
    [ "terminal", "close_8hpp.html#a3f9ce953f12693f74493e2eb7a80952b", null ]
];
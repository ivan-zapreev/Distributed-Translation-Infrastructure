var classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1trans__job__req =
[
    [ "trans_job_req", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1trans__job__req.html#a223207c27c0a0afc1c4fa525c628a560", null ],
    [ "~trans_job_req", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1trans__job__req.html#ad8cf42c7da442e4a66a7914ba4260ba7", null ]
];
var structuva_1_1smt_1_1bpbd_1_1client_1_1trans__job =
[
    [ "trans_job", "structuva_1_1smt_1_1bpbd_1_1client_1_1trans__job.html#a88712892ffaf03db8499e413d0b33e41", null ],
    [ "~trans_job", "structuva_1_1smt_1_1bpbd_1_1client_1_1trans__job.html#a96069250ad631223837837dd0e9694a3", null ],
    [ "m_num_sentences", "structuva_1_1smt_1_1bpbd_1_1client_1_1trans__job.html#a820ad0c2ec3ff0aaf83d7c80a67c2be2", null ],
    [ "m_request", "structuva_1_1smt_1_1bpbd_1_1client_1_1trans__job.html#a112405d2f528f5eef9bab3c5eff6b3b0", null ],
    [ "m_response", "structuva_1_1smt_1_1bpbd_1_1client_1_1trans__job.html#af1e33da2c5a209154915f5bf86e747c8", null ],
    [ "m_status", "structuva_1_1smt_1_1bpbd_1_1client_1_1trans__job.html#a11a9bf2812991f8e4e36b3884dc149f7", null ]
];
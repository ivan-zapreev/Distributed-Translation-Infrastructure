var classuva_1_1utils_1_1logging_1_1logger =
[
    [ "~logger", "classuva_1_1utils_1_1logging_1_1logger.html#aa695cb753a0876924c993863b8cd44d1", null ]
];
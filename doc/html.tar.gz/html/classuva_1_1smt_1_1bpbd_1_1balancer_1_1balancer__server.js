var classuva_1_1smt_1_1bpbd_1_1balancer_1_1balancer__server =
[
    [ "balancer_server", "classuva_1_1smt_1_1bpbd_1_1balancer_1_1balancer__server.html#a7febb39ba57d96151bae0260f18354d6", null ],
    [ "after_stop_listening", "classuva_1_1smt_1_1bpbd_1_1balancer_1_1balancer__server.html#a498f522044ba008c522861f994542e29", null ],
    [ "before_start_listening", "classuva_1_1smt_1_1bpbd_1_1balancer_1_1balancer__server.html#a9485136d8dc3bb0e8990e04a03b8d0a6", null ],
    [ "close_session", "classuva_1_1smt_1_1bpbd_1_1balancer_1_1balancer__server.html#a7d4c59f7837bf21e00dd1b849bc0793b", null ],
    [ "language_request", "classuva_1_1smt_1_1bpbd_1_1balancer_1_1balancer__server.html#a3fbedd280e07ddd5422f8f768b55f24a", null ],
    [ "open_session", "classuva_1_1smt_1_1bpbd_1_1balancer_1_1balancer__server.html#aa3c169d1a9646cd25e97355e26bcc96d", null ],
    [ "report_run_time_info", "classuva_1_1smt_1_1bpbd_1_1balancer_1_1balancer__server.html#a4308a9b15cbfe7e2d00062f528b758f3", null ],
    [ "set_num_inc_threads", "classuva_1_1smt_1_1bpbd_1_1balancer_1_1balancer__server.html#a60d65834ae094fdcce363464dd7e502f", null ],
    [ "set_num_out_threads", "classuva_1_1smt_1_1bpbd_1_1balancer_1_1balancer__server.html#a332502814c8c55efa215092b0b11895a", null ],
    [ "translation_request", "classuva_1_1smt_1_1bpbd_1_1balancer_1_1balancer__server.html#accc31aca0ea3295dda9dc4d128c0e78e", null ]
];
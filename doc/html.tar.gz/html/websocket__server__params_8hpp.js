var websocket__server__params_8hpp =
[
    [ "websocket_server_params_struct", "structuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1websocket_1_1websocket__server__params__struct.html", "structuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1websocket_1_1websocket__server__params__struct" ],
    [ "websocket_server_params", "websocket__server__params_8hpp.html#a42baa31d62daf039303593c8c9b62ff2", null ]
];
var classuva_1_1utils_1_1file_1_1memory__mapped__file__reader =
[
    [ "memory_mapped_file_reader", "classuva_1_1utils_1_1file_1_1memory__mapped__file__reader.html#a25cc1f08c01bb10ebf9911774e2be339", null ],
    [ "close", "classuva_1_1utils_1_1file_1_1memory__mapped__file__reader.html#ac61667c9806d9090393c545359f17154", null ],
    [ "get_first_line", "classuva_1_1utils_1_1file_1_1memory__mapped__file__reader.html#af43c82bb302a42220cdfc0b86b05a229", null ],
    [ "is_open", "classuva_1_1utils_1_1file_1_1memory__mapped__file__reader.html#a7caf2da4a6f9921f79174f9e70ab33a9", null ],
    [ "log_reader_type_info", "classuva_1_1utils_1_1file_1_1memory__mapped__file__reader.html#a077713a9e282b5ac04d79481c9bef5cb", null ],
    [ "operator bool", "classuva_1_1utils_1_1file_1_1memory__mapped__file__reader.html#ad0bf225d433850cfe9d6de9dda4aae99", null ]
];
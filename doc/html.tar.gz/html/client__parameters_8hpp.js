var client__parameters_8hpp =
[
    [ "client_parameters_struct", "structuva_1_1smt_1_1bpbd_1_1client_1_1client__parameters__struct.html", "structuva_1_1smt_1_1bpbd_1_1client_1_1client__parameters__struct" ],
    [ "client_parameters", "client__parameters_8hpp.html#af97adea5d05ac6e53015fda382668ca9", null ]
];
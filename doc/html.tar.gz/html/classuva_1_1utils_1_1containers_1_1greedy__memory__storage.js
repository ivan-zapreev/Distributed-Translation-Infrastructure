var classuva_1_1utils_1_1containers_1_1greedy__memory__storage =
[
    [ "size_type", "classuva_1_1utils_1_1containers_1_1greedy__memory__storage.html#a50b3509335bfab9e81ac0ec31b3a21ca", null ],
    [ "TStorageData", "classuva_1_1utils_1_1containers_1_1greedy__memory__storage.html#acd823736297e88cc06a6e69f2c692af3", null ],
    [ "greedy_memory_storage", "classuva_1_1utils_1_1containers_1_1greedy__memory__storage.html#a3d5e7e27b732146852c15ae14582bc1c", null ],
    [ "greedy_memory_storage", "classuva_1_1utils_1_1containers_1_1greedy__memory__storage.html#a359fdce02b4bc4bb8466db2880a1dfd8", null ],
    [ "greedy_memory_storage", "classuva_1_1utils_1_1containers_1_1greedy__memory__storage.html#a3d122546d87730a2b672427b0efeaa50", null ],
    [ "~greedy_memory_storage", "classuva_1_1utils_1_1containers_1_1greedy__memory__storage.html#aa961c9559b3fbaab26334629a85605ad", null ],
    [ "allocate", "classuva_1_1utils_1_1containers_1_1greedy__memory__storage.html#a9e1edb4d60cb58cb2cb0dd0f80f97dfa", null ],
    [ "getAvailableBytes", "classuva_1_1utils_1_1containers_1_1greedy__memory__storage.html#acfc4cb3e7b2a05bcd0735abd9b1eec0a", null ],
    [ "getBufferSizeBytes", "classuva_1_1utils_1_1containers_1_1greedy__memory__storage.html#a7dfdaf506cf29ce143972664df4b973d", null ],
    [ "_allocBytes", "classuva_1_1utils_1_1containers_1_1greedy__memory__storage.html#af0aa7e312dd1d044d1b303f0017caed5", null ],
    [ "_memoryBuffers", "classuva_1_1utils_1_1containers_1_1greedy__memory__storage.html#a03e3173b47437840289bc1f433772aaf", null ],
    [ "_numBytes", "classuva_1_1utils_1_1containers_1_1greedy__memory__storage.html#a78c24bbb9a07f246a1049cf476959510", null ],
    [ "_pBuffer", "classuva_1_1utils_1_1containers_1_1greedy__memory__storage.html#ade35ae22f918c450a3868f4e96c628ca", null ]
];
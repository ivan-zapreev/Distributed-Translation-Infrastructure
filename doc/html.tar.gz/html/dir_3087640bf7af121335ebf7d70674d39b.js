var dir_3087640bf7af121335ebf7d70674d39b =
[
    [ "logger.hpp", "logger_8hpp.html", "logger_8hpp" ]
];
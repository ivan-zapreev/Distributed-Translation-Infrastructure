var dir_358deac9c3d733b51d9a9e5a2c363846 =
[
    [ "common", "dir_09570de3dfb316c313be7ac6593bd1a2.html", "dir_09570de3dfb316c313be7ac6593bd1a2" ],
    [ "decoder", "dir_c450262778a4d4127d26ecd5f9ba20ae.html", "dir_c450262778a4d4127d26ecd5f9ba20ae" ],
    [ "lm", "dir_8f121a52a65b828732da1f81cb52102e.html", "dir_8f121a52a65b828732da1f81cb52102e" ],
    [ "rm", "dir_c5bf820dce585bef65cd265b6ce52e48.html", "dir_c5bf820dce585bef65cd265b6ce52e48" ],
    [ "tm", "dir_73f85d04f47fec289ac005a5c780084d.html", "dir_73f85d04f47fec289ac005a5c780084d" ],
    [ "cmd_line_handler.hpp", "cmd__line__handler_8hpp.html", "cmd__line__handler_8hpp" ],
    [ "server_configs.hpp", "server__configs_8hpp.html", "server__configs_8hpp" ],
    [ "server_consts.hpp", "server__consts_8hpp.html", "server__consts_8hpp" ],
    [ "server_parameters.hpp", "server__parameters_8hpp.html", "server__parameters_8hpp" ],
    [ "trans_job.hpp", "server_2trans__job_8hpp.html", "server_2trans__job_8hpp" ],
    [ "trans_job_pool.hpp", "trans__job__pool_8hpp.html", "trans__job__pool_8hpp" ],
    [ "trans_manager.hpp", "server_2trans__manager_8hpp.html", [
      [ "trans_manager", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__manager.html", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__manager" ]
    ] ],
    [ "trans_task.hpp", "trans__task_8hpp.html", "trans__task_8hpp" ],
    [ "trans_task_id.hpp", "trans__task__id_8hpp.html", "trans__task__id_8hpp" ],
    [ "trans_task_pool.hpp", "trans__task__pool_8hpp.html", [
      [ "trans_task_pool", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__task__pool.html", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__task__pool" ]
    ] ],
    [ "trans_task_pool_worker.hpp", "trans__task__pool__worker_8hpp.html", [
      [ "trans_task_pool_worker", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__task__pool__worker.html", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__task__pool__worker" ]
    ] ],
    [ "translation_server.hpp", "translation__server_8hpp.html", "translation__server_8hpp" ]
];
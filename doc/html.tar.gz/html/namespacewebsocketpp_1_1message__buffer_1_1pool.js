var namespacewebsocketpp_1_1message__buffer_1_1pool =
[
    [ "con_msg_manager", "classwebsocketpp_1_1message__buffer_1_1pool_1_1con__msg__manager.html", null ],
    [ "endpoint_msg_manager", "classwebsocketpp_1_1message__buffer_1_1pool_1_1endpoint__msg__manager.html", null ]
];
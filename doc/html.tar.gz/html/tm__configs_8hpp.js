var tm__configs_8hpp =
[
    [ "tm_builder_type", "tm__configs_8hpp.html#a29c513cbd5b9a3c3838ad34e5103776f", null ],
    [ "tm_model_reader", "tm__configs_8hpp.html#a252830a0bbad1555180821ed6ffce83f", null ],
    [ "tm_model_type", "tm__configs_8hpp.html#a2f41d3b9fcee3dddc005fd7e7deae402", null ]
];
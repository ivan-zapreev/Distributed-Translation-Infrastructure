var classuva_1_1smt_1_1bpbd_1_1server_1_1trans__job =
[
    [ "done_job_notifier", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__job.html#ad136e2791c7f5259a4e0974db72e7178", null ],
    [ "tasks_const_iter_type", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__job.html#ac1153b7924858b7cd9d7cb30d7586206", null ],
    [ "tasks_iter_type", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__job.html#a3e7878af85efafacb0af16bf5a13bb4a", null ],
    [ "tasks_list_type", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__job.html#a8d6020c8c7d17ba4bbb71fd85df6791d", null ],
    [ "trans_job", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__job.html#ace017f21aff5f23a9844767c7ec69503", null ],
    [ "~trans_job", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__job.html#a4cea7e8ebd0017b12736ef55753f302a", null ],
    [ "cancel", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__job.html#a285349f1d0300e617b7ac14b6894c9fe", null ],
    [ "combine_job_result", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__job.html#abc7c663ab0cf805bf368c89f7ec7af88", null ],
    [ "get_code", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__job.html#a2d0377b9dfa3ef4f181c922eeb0e004c", null ],
    [ "get_job_id", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__job.html#af6a0ebbf7f5a1090174afb826780778f", null ],
    [ "get_session_id", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__job.html#a0aaaf0f114b4c8e1f9816050ced3b1ae", null ],
    [ "get_tasks", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__job.html#a2370b9540596de89088097b4ef6a2129", null ],
    [ "get_text", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__job.html#a71d1c9bffeba77eb3914a618fba384bb", null ],
    [ "is_job_finished", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__job.html#ab0a7e64e9f33aa054e84973ffbb41e7c", null ],
    [ "notify_task_done", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__job.html#ad73d0212514b135378ef7798334af2eb", null ],
    [ "set_done_job_notifier", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__job.html#aaafc88ae2a94e07d4cab671006a9212a", null ],
    [ "wait_notify_finished", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__job.html#a8f2106836702c9f63eb89a55a6653cd0", null ]
];
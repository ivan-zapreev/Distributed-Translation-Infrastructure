var classuva_1_1smt_1_1bpbd_1_1server_1_1trans__job =
[
    [ "done_job_notifier", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__job.html#a70930fbe4255057957658e73a197af31", null ],
    [ "job_id_type", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__job.html#a909695c64c1e3c50cb0fc6c56f8c200b", null ],
    [ "tasks_const_iter_type", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__job.html#ac1153b7924858b7cd9d7cb30d7586206", null ],
    [ "tasks_iter_type", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__job.html#a3e7878af85efafacb0af16bf5a13bb4a", null ],
    [ "tasks_list_type", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__job.html#a8d6020c8c7d17ba4bbb71fd85df6791d", null ],
    [ "trans_job", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__job.html#a0510a3568b3c97e1f4dd66e1a08622eb", null ],
    [ "~trans_job", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__job.html#a4cea7e8ebd0017b12736ef55753f302a", null ],
    [ "cancel", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__job.html#a285349f1d0300e617b7ac14b6894c9fe", null ],
    [ "collect_job_results", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__job.html#a7c7a3942eb26f48f7008be18d0322506", null ],
    [ "get_job_id", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__job.html#abc07882fa1f4a0f3275fcef6c200f44e", null ],
    [ "get_session_id", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__job.html#af9379f39846ab356dc71fbaac8528ffc", null ],
    [ "get_tasks", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__job.html#ac4bb6e4c34b53200ef2fcc4c0dc3126c", null ],
    [ "is_job_finished", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__job.html#ab0a7e64e9f33aa054e84973ffbb41e7c", null ],
    [ "notify_task_done", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__job.html#ad73d0212514b135378ef7798334af2eb", null ],
    [ "set_done_job_notifier", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__job.html#aaafc88ae2a94e07d4cab671006a9212a", null ],
    [ "set_job_status", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__job.html#a9a3cd301b127ff2ebd8a60d8a822de52", null ],
    [ "synch_job_finished", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__job.html#a13d8a5bc23bb5a11ae0a696ea951ffbc", null ]
];
var structuva_1_1utils_1_1monitor_1_1memory__usage =
[
    [ "memory_usage", "structuva_1_1utils_1_1monitor_1_1memory__usage.html#ad03021f160590255f60451fe5f18603b", null ],
    [ "vmhwm", "structuva_1_1utils_1_1monitor_1_1memory__usage.html#a07b4f8b87babf609be5fdf760cad236a", null ],
    [ "vmpeak", "structuva_1_1utils_1_1monitor_1_1memory__usage.html#a7145c69ae9c7f75c38cd9a92df74f0e9", null ],
    [ "vmrss", "structuva_1_1utils_1_1monitor_1_1memory__usage.html#ab032109442efa2c08bd3085e562fc940", null ],
    [ "vmsize", "structuva_1_1utils_1_1monitor_1_1memory__usage.html#aa51584de084fc380578c457096a395ff", null ]
];
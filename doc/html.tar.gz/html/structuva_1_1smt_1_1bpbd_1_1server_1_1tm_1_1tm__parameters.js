var structuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1tm__parameters =
[
    [ "finalize", "structuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1tm__parameters.html#a62c75095cb2c90a4e0efdbb5af2ac9b1", null ],
    [ "m_conn_string", "structuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1tm__parameters.html#a6bdca6bec5481148be47c16d75d70a48", null ],
    [ "m_lambdas", "structuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1tm__parameters.html#a761a258aaa6b6652c268741ae732a882", null ],
    [ "m_min_tran_prob", "structuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1tm__parameters.html#a061ad92529a12c4c0cb8507c3f35e52e", null ],
    [ "m_num_lambdas", "structuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1tm__parameters.html#a19d5ff875562172e6249e96947fe6002", null ],
    [ "m_num_unk_features", "structuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1tm__parameters.html#a40a41b7331f9f582eeeb0a6d9629aac5", null ],
    [ "m_trans_limit", "structuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1tm__parameters.html#aca1973cf0099cb3cb94ddff5d52be20f", null ],
    [ "m_unk_features", "structuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1tm__parameters.html#a441e613ed28b4998341aaed3893bbd0f", null ]
];
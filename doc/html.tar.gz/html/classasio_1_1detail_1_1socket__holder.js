var classasio_1_1detail_1_1socket__holder =
[
    [ "socket_holder", "classasio_1_1detail_1_1socket__holder.html#a583c364271fa74a8292ec472009b1f40", null ],
    [ "socket_holder", "classasio_1_1detail_1_1socket__holder.html#aecdb304341764151be2fee5d4548b7f1", null ],
    [ "~socket_holder", "classasio_1_1detail_1_1socket__holder.html#ac20e117ae3baf80cce93c4deef2af2c5", null ],
    [ "get", "classasio_1_1detail_1_1socket__holder.html#acce8183ec40b137b333b0818724f750c", null ],
    [ "release", "classasio_1_1detail_1_1socket__holder.html#a319df4e1320692ff28e71b9601a42a8a", null ],
    [ "reset", "classasio_1_1detail_1_1socket__holder.html#a769000b0737ed610487ac9f490e77519", null ],
    [ "reset", "classasio_1_1detail_1_1socket__holder.html#ad025c1aacfd7186cf7a91cef7192b057", null ]
];
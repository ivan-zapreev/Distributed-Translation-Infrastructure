var classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1proxy_1_1tm__query__proxy =
[
    [ "~tm_query_proxy", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1proxy_1_1tm__query__proxy.html#aa4d6c9cdd01f021dca4c339d4d6a481e", null ],
    [ "execute", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1proxy_1_1tm__query__proxy.html#a190e349330a4f58b51b756983ce246b9", null ],
    [ "get_source_entry", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1proxy_1_1tm__query__proxy.html#afa67ada737121e1a4c1a302c7f82de32", null ],
    [ "get_st_uids", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1proxy_1_1tm__query__proxy.html#abe13dbef0b60b28709924789ff705235", null ]
];
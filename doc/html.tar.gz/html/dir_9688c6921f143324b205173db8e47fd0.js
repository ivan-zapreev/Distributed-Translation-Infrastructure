var dir_9688c6921f143324b205173db8e47fd0 =
[
    [ "task_pool.hpp", "task__pool_8hpp.html", [
      [ "task_pool", "classuva_1_1utils_1_1threads_1_1task__pool.html", "classuva_1_1utils_1_1threads_1_1task__pool" ],
      [ "less_task_priority", "structuva_1_1utils_1_1threads_1_1task__pool_1_1less__task__priority.html", "structuva_1_1utils_1_1threads_1_1task__pool_1_1less__task__priority" ]
    ] ],
    [ "task_pool_worker.hpp", "task__pool__worker_8hpp.html", [
      [ "task_pool", "classuva_1_1utils_1_1threads_1_1task__pool.html", "classuva_1_1utils_1_1threads_1_1task__pool" ],
      [ "task_pool_worker", "classuva_1_1utils_1_1threads_1_1task__pool__worker.html", "classuva_1_1utils_1_1threads_1_1task__pool__worker" ]
    ] ],
    [ "threads.hpp", "threads_8hpp.html", "threads_8hpp" ]
];
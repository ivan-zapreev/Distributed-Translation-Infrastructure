var trans__task_8hpp =
[
    [ "trans_task", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__task.html", "classuva_1_1smt_1_1bpbd_1_1server_1_1trans__task" ],
    [ "trans_task_ptr", "trans__task_8hpp.html#a4dea4bb1185fe5d148be18ad12fea74a", null ],
    [ "operator<<", "trans__task_8hpp.html#a7a61b97b290dd8163c63dfdda505b142", null ]
];
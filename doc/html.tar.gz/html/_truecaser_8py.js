var _truecaser_8py =
[
    [ "getScore", "_truecaser_8py.html#a56aeb2281575fb1ff1fabeb40deb3584", null ],
    [ "getTrueCase", "_truecaser_8py.html#aedd4a628b8273e6c094f33463b516d6c", null ]
];
var classuva_1_1smt_1_1bpbd_1_1server_1_1translation__manager =
[
    [ "translation_manager", "classuva_1_1smt_1_1bpbd_1_1server_1_1translation__manager.html#af68c6ab8efca5a27a18db4ef1276503a", null ],
    [ "~translation_manager", "classuva_1_1smt_1_1bpbd_1_1server_1_1translation__manager.html#a2f1b1657d2973d1873af58a7520811b9", null ],
    [ "notify_job_done", "classuva_1_1smt_1_1bpbd_1_1server_1_1translation__manager.html#ab2a127435a27059e704135de14cf16ed", null ],
    [ "report_run_time_info", "classuva_1_1smt_1_1bpbd_1_1server_1_1translation__manager.html#a0fe5e0d6704c79d560bdb6b53903a4ae", null ],
    [ "schedule_new_job", "classuva_1_1smt_1_1bpbd_1_1server_1_1translation__manager.html#a852d2a5dab933d0d4006c0987b84127e", null ],
    [ "session_is_closed", "classuva_1_1smt_1_1bpbd_1_1server_1_1translation__manager.html#a7c49d0c00fa20fe192be6ffd8da5920c", null ],
    [ "set_num_threads", "classuva_1_1smt_1_1bpbd_1_1server_1_1translation__manager.html#aac640dad3820ff955d941eb76b22f55e", null ],
    [ "stop", "classuva_1_1smt_1_1bpbd_1_1server_1_1translation__manager.html#a985fafaf8f7e96ab3639464831afcd76", null ],
    [ "translate", "classuva_1_1smt_1_1bpbd_1_1server_1_1translation__manager.html#a5c3c3f778f1a33be2d7b4f6b4fd1e85e", null ]
];
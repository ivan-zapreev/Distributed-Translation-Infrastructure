var classuva_1_1smt_1_1bpbd_1_1server_1_1messaging_1_1trans__job__req__in =
[
    [ "trans_job_req_in", "classuva_1_1smt_1_1bpbd_1_1server_1_1messaging_1_1trans__job__req__in.html#ad5bd4e37a0201564123fc8eaf3074ff5", null ],
    [ "~trans_job_req_in", "classuva_1_1smt_1_1bpbd_1_1server_1_1messaging_1_1trans__job__req__in.html#a130acd2075547cfe6276621cac5b044e", null ],
    [ "get_job_id", "classuva_1_1smt_1_1bpbd_1_1server_1_1messaging_1_1trans__job__req__in.html#a5dad4edb762935aadc45b37b0b35484c", null ],
    [ "get_message", "classuva_1_1smt_1_1bpbd_1_1server_1_1messaging_1_1trans__job__req__in.html#a98ae621c016f4d4847059454e7bfd643", null ],
    [ "get_priority", "classuva_1_1smt_1_1bpbd_1_1server_1_1messaging_1_1trans__job__req__in.html#a5bd84f9909ba49028d97d2624ff3363a", null ],
    [ "get_source_lang", "classuva_1_1smt_1_1bpbd_1_1server_1_1messaging_1_1trans__job__req__in.html#af6e80e2c9f1aeb6b90d7700a8acfeb79", null ],
    [ "get_source_lang_uid", "classuva_1_1smt_1_1bpbd_1_1server_1_1messaging_1_1trans__job__req__in.html#adff7d38839b7f979eea90a5f5575888a", null ],
    [ "get_source_text", "classuva_1_1smt_1_1bpbd_1_1server_1_1messaging_1_1trans__job__req__in.html#a15a5d12f9a11c75ec852de3facb0f0d9", null ],
    [ "get_target_lang", "classuva_1_1smt_1_1bpbd_1_1server_1_1messaging_1_1trans__job__req__in.html#ae7073af7cb175e7568ce46d6372f241c", null ],
    [ "get_target_lang_uid", "classuva_1_1smt_1_1bpbd_1_1server_1_1messaging_1_1trans__job__req__in.html#afe4c5a2f5c3c1d489f41028495d5e466", null ],
    [ "is_trans_info", "classuva_1_1smt_1_1bpbd_1_1server_1_1messaging_1_1trans__job__req__in.html#a8c5a5f4e70f3713670adcd9ed2a38038", null ],
    [ "set_job_id", "classuva_1_1smt_1_1bpbd_1_1server_1_1messaging_1_1trans__job__req__in.html#a28638dfdc09d5ce601e9f2470a8d3acd", null ]
];
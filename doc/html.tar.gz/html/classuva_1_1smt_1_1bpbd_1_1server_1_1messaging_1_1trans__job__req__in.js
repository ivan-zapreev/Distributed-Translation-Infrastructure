var classuva_1_1smt_1_1bpbd_1_1server_1_1messaging_1_1trans__job__req__in =
[
    [ "trans_job_req_in", "classuva_1_1smt_1_1bpbd_1_1server_1_1messaging_1_1trans__job__req__in.html#ad5bd4e37a0201564123fc8eaf3074ff5", null ],
    [ "~trans_job_req_in", "classuva_1_1smt_1_1bpbd_1_1server_1_1messaging_1_1trans__job__req__in.html#a130acd2075547cfe6276621cac5b044e", null ],
    [ "get_job_id", "classuva_1_1smt_1_1bpbd_1_1server_1_1messaging_1_1trans__job__req__in.html#a1397f91888e152fb24de4e6162cf343d", null ],
    [ "get_message", "classuva_1_1smt_1_1bpbd_1_1server_1_1messaging_1_1trans__job__req__in.html#a92b4f11a03ea9f567f5e6120795243c2", null ],
    [ "get_priority", "classuva_1_1smt_1_1bpbd_1_1server_1_1messaging_1_1trans__job__req__in.html#acb610a677156407a7ab8345436e85b6f", null ],
    [ "get_source_lang", "classuva_1_1smt_1_1bpbd_1_1server_1_1messaging_1_1trans__job__req__in.html#ad67d0c5f8c34f48066df15d40c18d781", null ],
    [ "get_source_lang_uid", "classuva_1_1smt_1_1bpbd_1_1server_1_1messaging_1_1trans__job__req__in.html#af4ddbaab74015aa885e41e227b2fa5b8", null ],
    [ "get_source_text", "classuva_1_1smt_1_1bpbd_1_1server_1_1messaging_1_1trans__job__req__in.html#ab5737c1509d0a092dc0bb40660e213d0", null ],
    [ "get_target_lang", "classuva_1_1smt_1_1bpbd_1_1server_1_1messaging_1_1trans__job__req__in.html#a5ccb939133101998ff552488ff10dbad", null ],
    [ "get_target_lang_uid", "classuva_1_1smt_1_1bpbd_1_1server_1_1messaging_1_1trans__job__req__in.html#a15dc67ca81454088209d26cfc70fc69e", null ],
    [ "is_trans_info", "classuva_1_1smt_1_1bpbd_1_1server_1_1messaging_1_1trans__job__req__in.html#a6bc77e04499b34c3db5aaf44f2a07001", null ],
    [ "set_job_id", "classuva_1_1smt_1_1bpbd_1_1server_1_1messaging_1_1trans__job__req__in.html#a28638dfdc09d5ce601e9f2470a8d3acd", null ]
];
var classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1models_1_1tm__target__entry =
[
    [ "tm_target_entry", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1models_1_1tm__target__entry.html#ac4e7e1a4eeb33cb549728a8a65502cd9", null ],
    [ "~tm_target_entry", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1models_1_1tm__target__entry.html#a4bc8e5e2f33e7c50b0afc27fd65b279a", null ],
    [ "get_num_words", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1models_1_1tm__target__entry.html#a98e837be3f5823a1e948c7cd66c108e7", null ],
    [ "get_st_uid", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1models_1_1tm__target__entry.html#a03d323dbae469ac7062b6a1d10be381f", null ],
    [ "get_target_phrase", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1models_1_1tm__target__entry.html#a3ee1ce2bffe163ea04d95ac0effa9583", null ],
    [ "get_tm_cost", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1models_1_1tm__target__entry.html#ae22a3f7d86cec371a90d7d1360917dab", null ],
    [ "get_word_ids", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1models_1_1tm__target__entry.html#ae85ccb0c1364a26ba279aecd53d3e62a", null ],
    [ "is_unk_trans", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1models_1_1tm__target__entry.html#aafcac97135b910b68f862718446f2f4e", null ],
    [ "move_from", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1models_1_1tm__target__entry.html#a9573c6d89786eeb3fc6a4d2df70263f6", null ],
    [ "operator<", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1models_1_1tm__target__entry.html#a9565cfcd02055a68de2902a25fe2a5a5", null ],
    [ "set_data", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1models_1_1tm__target__entry.html#a2141033bd12decb85608c97d9b8e9a2a", null ],
    [ "set_features", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1models_1_1tm__target__entry.html#a53575433f61d0e548cf1e666dae2f6a0", null ]
];
var classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1_w2_c_h___u_m___storage_factory =
[
    [ "W2CH_UM_StorageFactory", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1_w2_c_h___u_m___storage_factory.html#aa6ecf82dcaf503dd92af8763cb90b093", null ],
    [ "~W2CH_UM_StorageFactory", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1_w2_c_h___u_m___storage_factory.html#ad3fa9bea0072bda045c90512c5ae8d7a", null ],
    [ "create", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1_w2_c_h___u_m___storage_factory.html#ab360ad98835a2d1f4ec6fb91ad35bb83", null ],
    [ "m_p_alloc", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1_w2_c_h___u_m___storage_factory.html#a2191bc31eb8246da200e8c39a353c0f8", null ]
];
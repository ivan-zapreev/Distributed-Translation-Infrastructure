var _evaluate_truecaser_8py =
[
    [ "defaultTruecaserEvaluation", "_evaluate_truecaser_8py.html#ab26fd66f1ab0554c553954a9eb2ee8d0", null ],
    [ "evaluateTrueCaser", "_evaluate_truecaser_8py.html#a6afcc2e7944db4bc1c7a128ff6122f67", null ],
    [ "backwardBiDist", "_evaluate_truecaser_8py.html#a89a7808ce7c556236776437af09b3186", null ],
    [ "f", "_evaluate_truecaser_8py.html#ab3bf3a8fc194a3cf0dd63105f308a6ac", null ],
    [ "forwardBiDist", "_evaluate_truecaser_8py.html#a1c19f4a2db267b26309133de5b4ceb0f", null ],
    [ "trigramDist", "_evaluate_truecaser_8py.html#ae5165972a5bb6082b19da88d0dea26b5", null ],
    [ "uniDist", "_evaluate_truecaser_8py.html#a3bbcd4f6dcc28660c1add38196644cbf", null ],
    [ "wordCasingLookup", "_evaluate_truecaser_8py.html#a2936da5d52457a9f4e4af0dd763d8803", null ]
];
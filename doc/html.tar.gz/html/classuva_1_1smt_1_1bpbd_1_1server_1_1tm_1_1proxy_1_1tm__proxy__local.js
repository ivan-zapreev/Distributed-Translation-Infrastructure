var classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1proxy_1_1tm__proxy__local =
[
    [ "tm_proxy_local", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1proxy_1_1tm__proxy__local.html#aa713e38d275c6d6c47e4e437f4c196d3", null ],
    [ "~tm_proxy_local", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1proxy_1_1tm__proxy__local.html#a1438086facfafb8ad22b381232e6e474", null ],
    [ "allocate_query_proxy", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1proxy_1_1tm__proxy__local.html#a5d5b8fbfe884af27c390e38b065f399c", null ],
    [ "connect", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1proxy_1_1tm__proxy__local.html#a5d77b90071d5ea0c80072a4b14125edf", null ],
    [ "disconnect", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1proxy_1_1tm__proxy__local.html#a000e14c8242bbe551cdc074c79ef0b89", null ],
    [ "dispose_query_proxy", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1proxy_1_1tm__proxy__local.html#af91a15abfca464b58f7e752ebc258364", null ],
    [ "load_model_data", "classuva_1_1smt_1_1bpbd_1_1server_1_1tm_1_1proxy_1_1tm__proxy__local.html#ab55bb64bacfd5243dec3c683793cb7f7", null ]
];
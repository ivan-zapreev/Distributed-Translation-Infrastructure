var classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1trans__job__request =
[
    [ "trans_job_request", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1trans__job__request.html#ab37b117a127c254fd0f827aa047b729b", null ],
    [ "trans_job_request", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1trans__job__request.html#a2d22d61a43e020d2197bc22242659343", null ],
    [ "de_serialize", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1trans__job__request.html#ac067d665bd9c6ce448dbc67bb736090a", null ],
    [ "get_job_id", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1trans__job__request.html#a6dbfb9696acf036811fe4e9d2f11a4aa", null ],
    [ "get_session_id", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1trans__job__request.html#a83cd363fff23deba471f915251001192", null ],
    [ "get_source_lang", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1trans__job__request.html#a61a2e12cdbb970b985f2c3802b87776a", null ],
    [ "get_target_lang", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1trans__job__request.html#a0500f2e2bda7356205d3bfc36097e36c", null ],
    [ "get_text", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1trans__job__request.html#a9f77f64de2dd4ea6d1cc23a86563644e", null ],
    [ "is_trans_info", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1trans__job__request.html#a1fb007c6e111802f0f465aa343737096", null ],
    [ "serialize", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1trans__job__request.html#a911f136256ac5245060cba3bf0be28ed", null ],
    [ "set_session_id", "classuva_1_1smt_1_1bpbd_1_1common_1_1messaging_1_1trans__job__request.html#a1ba9bf5f2315b9de58b105f01e051c8c", null ]
];
var classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1generic__trie__base =
[
    [ "BASE", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1generic__trie__base.html#ace5120d75920dacafb1564eca63b6885", null ],
    [ "generic_trie_base", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1generic__trie__base.html#ac63c346d3aa5cbcc5268faeeafe0fba0", null ],
    [ "~generic_trie_base", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1generic__trie__base.html#a192f7e1e6ec4dcf2a4b8f502e345a4bc", null ],
    [ "add_m_gram", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1generic__trie__base.html#ad8849c7d2e5001663e3d43748dc54360", null ],
    [ "execute", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1generic__trie__base.html#abe0f1395bfe1c4d3b3cf33ca6071daa6", null ],
    [ "get_m_gram_payload", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1generic__trie__base.html#a7169867c7fa2574dd8b6a03fb30339d2", null ],
    [ "get_n_gram_payload", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1generic__trie__base.html#aaf7ba4de7f980e7e37c297caabc71ad7", null ],
    [ "get_unigram_payload", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1generic__trie__base.html#a73bfcff75e55219762cfe13e98cd940e", null ],
    [ "get_unk_word_prob", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1generic__trie__base.html#a1bc9eaa24ea40f2c777f9fc3959eca05", null ],
    [ "is_m_gram_potentially_present", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1generic__trie__base.html#a698bd222f7064a0149c94ceca7bd2ab4", null ],
    [ "log_model_type_info", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1generic__trie__base.html#a8ad8404f4c03339ed2a22247271dff0e", null ],
    [ "pre_allocate", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1generic__trie__base.html#acd30b95a28c0df80354b105526e71c29", null ],
    [ "register_m_gram_cache", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1generic__trie__base.html#aca43a446218a34804a37f20eb5d36294", null ]
];
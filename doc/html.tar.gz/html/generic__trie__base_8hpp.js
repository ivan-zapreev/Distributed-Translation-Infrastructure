var generic__trie__base_8hpp =
[
    [ "generic_trie_base", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1generic__trie__base.html", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1generic__trie__base" ],
    [ "INSTANTIATE_TRIE_FUNCS_LEVEL", "generic__trie__base_8hpp.html#a48cbc63327221ef60d3cbe084d7432ce", null ],
    [ "INSTANTIATE_TRIE_TEMPLATE_TYPE", "generic__trie__base_8hpp.html#a2765078929a27130518e2390a12923b9", null ],
    [ "REPORT_COLLISION_WARNING", "generic__trie__base_8hpp.html#aff304331a07b4be71f28da2444145026", null ],
    [ "MGramStatusEnum", "generic__trie__base_8hpp.html#ab9b3e7382b561dcb8abcd6b55e9b796a", [
      [ "UNDEFINED_MGS", "generic__trie__base_8hpp.html#ab9b3e7382b561dcb8abcd6b55e9b796aa9019f6deb96568ca044e6c1849e446cb", null ],
      [ "BAD_END_WORD_UNKNOWN_MGS", "generic__trie__base_8hpp.html#ab9b3e7382b561dcb8abcd6b55e9b796aab88dace63609938caf3106666433cd1c", null ],
      [ "BAD_NO_PAYLOAD_MGS", "generic__trie__base_8hpp.html#ab9b3e7382b561dcb8abcd6b55e9b796aaf10f109b34b87eedfb0ec95d81bfa931", null ],
      [ "GOOD_PRESENT_MGS", "generic__trie__base_8hpp.html#ab9b3e7382b561dcb8abcd6b55e9b796aa4682346ec5c105689f1d0bc41af318a9", null ]
    ] ]
];
var classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1proxy_1_1lm__slow__query__proxy =
[
    [ "~lm_slow_query_proxy", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1proxy_1_1lm__slow__query__proxy.html#a53222e4917ec99a2c5036dbfbf27564d", null ],
    [ "execute", "classuva_1_1smt_1_1bpbd_1_1server_1_1lm_1_1proxy_1_1lm__slow__query__proxy.html#aae7c3726774ded484d4757039d28e138", null ]
];